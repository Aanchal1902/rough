/*
 * seed-mongo.js — pure-DB seeding for the Checkout Channel Composer.
 *
 * A standalone alternative to the Java WidgetTemplateSeeder: it populates the same three
 * collections (channel_config, widget_config, widget_template) directly, without running the
 * BFF or the composer JAR. Hand it to a DBA, run it in CI, or use it for local bootstrap.
 *
 * It reads the bundled seed data straight from src/main/resources/seed so it never drifts from
 * the templates the library ships with.
 *
 * ---------------------------------------------------------------------------------------------
 * USAGE (run with mongosh — it bundles Node, so require('fs') is available):
 *
 *   # from the project root (checkout-channel-composer/)
 *   mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
 *
 *   # overwrite existing docs / publish a new template version even if one already exists
 *   OVERWRITE=true mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
 *
 *   # point at a seed dir other than the default (absolute or relative to your CWD)
 *   SEED_DIR=/path/to/seed mongosh "mongodb://host/db" scripts/seed-mongo.js
 *
 * The target database comes from the connection string — the script writes to the current `db`.
 * ---------------------------------------------------------------------------------------------
 */

const fs = require('fs');

const CONFIG = {
  // Directory containing channel/, widget/, templates/. Default assumes CWD = project root.
  seedDir: (process.env && process.env.SEED_DIR) || 'src/main/resources/seed',
  // false = only insert what's missing (like composer.seed.overwrite=false).
  // true  = re-upsert configs and publish a NEW template version even when an ACTIVE one exists.
  overwrite: !!(process.env && process.env.OVERWRITE && process.env.OVERWRITE !== 'false'),
};

const TEMPLATES_ROOT = CONFIG.seedDir + '/templates';

// --- small fs helpers (avoid require('path') so this stays maximally portable) --------------

function readUtf8(p) {
  return fs.readFileSync(p, 'utf8');
}

function listFilesRecursive(dir, suffix) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = dir + '/' + entry.name;
    if (entry.isDirectory()) {
      out.push.apply(out, listFilesRecursive(full, suffix));
    } else if (entry.name.endsWith(suffix)) {
      out.push(full);
    }
  }
  return out;
}

/** Logical template name = path after templates/, normalised to forward slashes. */
function templateNameOf(fullPath) {
  let rel = fullPath.substring(TEMPLATES_ROOT.length);
  rel = rel.replace(/\\/g, '/').replace(/^\/+/, '');
  return rel;
}

// --- indexes: mirror the @Document / @CompoundIndexes on the Java models --------------------

function ensureIndexes() {
  // Channel config indexes
  db.channel_config.createIndex(
    {
      channel: 1,
      journey: 1,
      journeyFlow: 1,
      flowVariant: 1,
      persona: 1,
      checkout: 1,
      step: 1
    },
    { unique: true, name: 'channel_journey_flow_unique' }
  );

  // Channel widget config indexes
  db.channel_widget_config.createIndex({ widgetId: 1, version: 1 }, { unique: true, name: 'widgetId_version_unique' });

  // Widgets config indexes
  db.widgets.createIndex({ channelId: 1, subChannelId: 1 }, { unique: true, name: 'channel_subChannel_unique' });

  print('Ensured indexes on channel_config, channel_widget_config, widgets');
}

// --- versioned publish: mirrors WidgetTemplateVersionService.publishNewVersion + markLastKnownGood

function publishVersion(name, content, description) {
  const coll = db.widget_template;
  const hasActive = coll.countDocuments({ name: name, status: 'ACTIVE' }) > 0;
  if (hasActive && !CONFIG.overwrite) {
    print("  skip template '" + name + "' (ACTIVE version exists, overwrite=false)");
    return;
  }

  const top = coll.find({ name: name }).sort({ version: -1 }).limit(1).toArray()[0];
  const nextVersion = top ? top.version + 1 : 1;

  // Demote the current ACTIVE version to INACTIVE (kept as a fallback candidate).
  if (hasActive) {
    coll.updateMany(
      { name: name, status: 'ACTIVE' },
      { $set: { status: 'INACTIVE', lastModified: Date.now() } });
  }

  const now = Date.now();
  coll.insertOne({
    name: name,
    version: nextVersion,
    content: content,
    description: description,
    status: 'ACTIVE',
    // Seed templates are the trusted baseline, so they are known-good immediately —
    // this is what makes them eligible as a fallback for future broken versions.
    lastKnownGood: true,
    createdAt: now,
    lastModified: now,
  });
  print("  published template '" + name + "' v" + nextVersion + " (ACTIVE, lastKnownGood)");
}

// --- config upsert: mirrors WidgetTemplateSeeder.seedChannelConfig / seedWidgetConfig --------

function upsertChannelConfig(doc) {
  let filter, identifier;

  // Use new structure if available
  if (doc.channel && doc.journey) {
    filter = {
      channel: doc.channel,
      journey: doc.journey,
      journeyFlow: doc.journeyFlow || 'DEFAULT',
      flowVariant: doc.flowVariant || 'DEFAULT',
      persona: doc.persona || 'customer',
      checkout: doc.checkout || 'STANDARD',
      step: doc.step || 'CHECKOUT'
    };
    identifier = doc.channel + '/' + doc.journey;
  } else {
    // Fallback to legacy structure
    filter = { channelKey: doc.channelKey };
    identifier = doc.channelKey;
  }

  const exists = db.channel_config.countDocuments(filter) > 0;
  if (exists && !CONFIG.overwrite) {
    print("  skip channel_config '" + identifier + "' (exists, overwrite=false)");
    return;
  }
  db.channel_config.replaceOne(filter, doc, { upsert: true });
  print("  upserted channel_config '" + identifier + "'");
}

function upsertWidgets(doc) {
  const filter = { channelId: doc.channelId, subChannelId: doc.subChannelId };
  const identifier = doc.channelId + '/' + doc.subChannelId;

  const exists = db.widgets.countDocuments(filter) > 0;
  if (exists && !CONFIG.overwrite) {
    print("  skip widgets '" + identifier + "' (exists, overwrite=false)");
    return;
  }
  db.widgets.replaceOne(filter, doc, { upsert: true });
  print("  upserted widgets '" + identifier + "'");
}

function upsertChannelWidgetConfig(doc) {
  const filter = { widgetId: doc.widgetId, version: doc.version };
  const identifier = doc.widgetId + '@' + doc.version;

  const exists = db.channel_widget_config.countDocuments(filter) > 0;
  if (exists && !CONFIG.overwrite) {
    print("  skip channel_widget_config '" + identifier + "' (exists, overwrite=false)");
    return;
  }
  db.channel_widget_config.replaceOne(filter, doc, { upsert: true });
  print("  upserted channel_widget_config '" + identifier + "'");
}

function seedConfigDir(subdir, collName) {
  const dir = CONFIG.seedDir + '/' + subdir;
  if (!fs.existsSync(dir)) {
    print('No ' + subdir + ' dir at ' + dir + ' — skipping');
    return;
  }
  for (const file of listFilesRecursive(dir, '.json')) {
    const doc = JSON.parse(readUtf8(file));
    if (collName === 'channel_config') {
      upsertChannelConfig(doc);
    } else if (collName === 'widgets') {
      upsertWidgets(doc);
    } else if (collName === 'channel_widget_config') {
      upsertChannelWidgetConfig(doc);
    }
  }
}

// --- run ------------------------------------------------------------------------------------

print('Channel Composer seed starting (seedDir=' + CONFIG.seedDir + ', overwrite=' + CONFIG.overwrite + ')');

ensureIndexes();

print('Seeding channel_config');
seedConfigDir('channel', 'channel_config');

print('Seeding widgets');
seedConfigDir('widget', 'widgets');

print('Seeding channel_widget_config');
seedConfigDir('channel-widget', 'channel_widget_config');

print('Channel Composer seed finished');
