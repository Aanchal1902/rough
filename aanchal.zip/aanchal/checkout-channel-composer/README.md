# Checkout Channel Composer

A **library (JAR)** — not a running service — that turns canonical checkout data into the
channel-specific, widget-based JSON the frontend consumes. It replaces the monolithic per-core-system
FreeMarker templates (e.g. `group-checkout.ftl`) with a **database-driven** composition model.

There is deliberately **no REST API**. The Checkout BFF adds this JAR as a dependency and calls
`ChannelComposerService` in-process.

## Where it sits

```
Frontend ──▶ Checkout BFF (/checkoutPage)
                 │  1. calls the core system (e.g. Group Renewal), gets the order response
                 │  2. maps it to a canonical data object (the "data")
                 ▼
         ChannelComposerService.compose(ComposeRequest{ channelKey, data })   ◀── this library
                 │  3. loads channel config + widget config + widget FTLs from MongoDB
                 │  4. renders each enabled widget, assembles the final widget JSON
                 ▼
         ComposedResponse{ data: <widget JSON> }
                 │
Frontend ◀── Checkout BFF
```

## The three MongoDB collections

| Collection        | Document           | Purpose |
|-------------------|--------------------|---------|
| `channel_config`  | `ChannelConfig`    | Per-channel details: redirection URLs, home/exit URLs, feature flags (`hideAdditionalCovers`, …). Looked up by `channelKey`. |
| `widget_config`   | `WidgetConfig`     | Which widgets render for a channel, in what **order**, which template each uses, and the **output key** it lands under. |
| `widget_template` | `WidgetTemplate`   | The FreeMarker source for each widget, plus shared `<#include>` fragments. **Versioned** — many documents per logical `name`, one per version (see below). |

FreeMarker resolves **all** templates (widgets and `<#include>` fragments) from `widget_template`
via a custom `MongoTemplateLoader` — nothing is read from the classpath at runtime.

## Template versioning & self-healing fallback

Every `widget_template` document is one **version** of a logical template `name`. You never edit a
template in place — you **publish a new version**, and the previous one is retained.

Each document carries:

| Field           | Meaning |
|-----------------|---------|
| `name`          | Logical template name, e.g. `group-renewal/pricing-section.ftl`. Shared across all its versions. |
| `version`       | Monotonic integer. `publishNewVersion` inserts `max(version) + 1`. |
| `status`        | `ACTIVE` or `INACTIVE`. **At most one `ACTIVE` per `name`** — the version served by default. |
| `lastKnownGood` | `true` once a version has rendered successfully at least once. Used to pick a safe fallback. |

Publishing a new version (`WidgetTemplateVersionService.publishNewVersion`) inserts it as the new
`ACTIVE` and demotes the previously active one to `INACTIVE` (kept as a fallback candidate).
FreeMarker addresses a specific version through a version-pinned name (`name@version`) that the
`MongoTemplateLoader` understands; an unpinned name resolves the current `ACTIVE`.

### The resilience guarantee

Composition is **failure-isolated per widget** — one broken widget never breaks the page:

1. **Active** — render the widget's `ACTIVE` version. On success it is marked `lastKnownGood` and
   added to `renderedWidgets`.
2. **Fallback** — if the active version throws (bad template, invalid JSON, …), render the last
   `lastKnownGood` version *other than* the one that just failed. Served this way, the widget is
   added to `fallbackWidgets`.
3. **Skip** — if the fallback also fails (or none exists), the widget is dropped and added to
   `failedWidgets`. **Every other widget still renders**, and the overall response is returned.

A template that legitimately renders blank (e.g. an entity-gated section that only shows for
`customer`) is a **success**, not a failure — it is simply omitted from the output.

`ComposedResponse` reports the outcome: `renderedWidgets`, `fallbackWidgets`, `failedWidgets`, and
`isDegraded()` (true if anything fell back or failed). The page is safe to show whenever `data` is
present, regardless of `isDegraded()`.

### Rolling forward and back

- **New template / change:** `publishNewVersion(name, content, description)` → new `ACTIVE`, old one
  kept as `INACTIVE` fallback.
- **A published version is broken:** nothing to do at request time — it auto-falls-back to the last
  known-good version on every request. To make the rollback permanent, publish a corrected version
  (or re-activate a good one).

## The composition model passed to each widget FTL

`ComposeRequest.data` (any POJO or `Map`) is **flattened to the model root**, so existing templates
that reference top-level fields keep working unchanged:

- `productInfo`, `masterPolicies`, `editableContext`, `groupPaymentPreferences`,
  `groupPricingSection`, `autoRenewalEnabled`, `orderDetails`, `advisorDetails`, …

Plus a `channelConfig` namespace layered on top:

- `channelConfig.redirectionUrls.goToBackHomePageUrl`, `channelConfig.hideAdditionalCovers`, …

Anything in `ComposeRequest.attributes` is merged last (request-time overrides).

## How the BFF uses it

```java
@RequiredArgsConstructor
class GroupRenewalCheckoutServiceImpl implements CheckoutStrategy {

  private final ChannelComposerService channelComposerService;   // autowired from the JAR

  public ApiResponse buildCheckoutPage(CheckoutParamsRequest req, HttpServletRequest http) {
    CheckoutResponse checkoutResponse = /* ... build canonical data as today ... */;

    ComposedResponse composed = channelComposerService.compose(
        ComposeRequest.builder()
            .channelKey("GROUP_RENEWAL")
            .data(checkoutResponse)          // passed in-process, no serialization
            .build());

    ApiResponse response = new ApiResponse();
    response.setMessage("Checkout page fetched successfully!");
    response.setData(composed.getData());    // the assembled widget JSON
    return response;
  }
}
```

No configuration classes or component-scan changes are needed in the BFF — the library
auto-configures itself (`META-INF/spring/...AutoConfiguration.imports`). The BFF only needs a
MongoDB connection (`spring.data.mongodb.uri`).

## Group Renewal — the seeded example

`src/main/resources/seed/` contains a full worked example decomposed from the original
`group-checkout.ftl`:

- `channel/group-renewal-channel.json` — the channel config
- `widget/group-renewal-widgets.json` — the widget list & order
- `templates/group-renewal/*.ftl` — one FTL per widget: `header`, `product-info`,
  `product-modify-options`, `emi-section`, `auto-renewal-section`, `terms-and-conditions`,
  `pricing-section`
- `templates/common/group-premium-breakup.ftl` — shared `<#include>` fragment
  **(placeholder — replace with the real fragment; it was not part of the handover)**

### Seeding

Off by default. To bootstrap a local/dev Mongo from the bundled seed:

```properties
composer.seed.enabled=true      # run the seeder
composer.seed.overwrite=false   # true = replace existing docs; false = only insert missing
```

In real environments the config + templates are managed directly in Mongo, so leave seeding off.

### Pure-DB seeding (no app run)

`scripts/seed-mongo.js` populates the same three collections directly with `mongosh`, without
starting the BFF or the composer JAR. It reads the bundled `src/main/resources/seed` data, creates
the same indexes Spring expects, and publishes each template as an `ACTIVE` v1 marked
`lastKnownGood` — identical semantics to the Java seeder.

```bash
# from the project root
mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js

# overwrite configs / publish a new template version even if one already exists
OVERWRITE=true mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js

# use a different seed directory
SEED_DIR=/path/to/seed mongosh "mongodb://host/db" scripts/seed-mongo.js
```

The target database comes from the connection string. Re-running is safe: by default it inserts
only what's missing (`OVERWRITE=false`); with `OVERWRITE=true` it re-upserts configs and publishes
a **new** template version (demoting the previous active to a fallback), never editing in place.

## Adding a new channel

1. Insert a `channel_config` document (new `channelKey`).
2. Insert a `widget_config` document listing its widgets, order, template names and output keys.
3. Publish the `widget_template` versions its widgets reference (each as an `ACTIVE` v1).

No code change or redeploy required — it's all data.

## Notes / follow-ups

- `group-premium-breakup.ftl` is a placeholder; swap in the real premium-breakup FTL.
- `MDC`/session-derived values that the monolith read from headers should be passed by the BFF
  via `ComposeRequest.data` or `.attributes` — the composer has no request scope.
- The CTA decider, page-status/expiry validation and redirection-URL fetching stay in the BFF
  (or their own split-out services); the composer is presentation only.
