package com.star.checkout.composer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

/**
 * Defines WHICH widgets render for a channel, in what ORDER, and which FTL each widget uses.
 *
 * <p>One document per channel. The composition engine iterates {@link #widgets} in {@code order},
 * renders the referenced {@link WidgetTemplate} for each enabled widget, and assembles the final
 * response object keyed by {@link WidgetDefinition#outputKey}.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "widget_config")
public class WidgetConfig {

  @Id
  private String id;

  /** Matches {@link ChannelConfig#getChannelKey()}, e.g. "GROUP_RENEWAL". */
  @Indexed(unique = true)
  private String channelKey;

  /** Ordered list of widgets to compose for this channel. */
  @Builder.Default
  private List<WidgetDefinition> widgets = new ArrayList<>();

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class WidgetDefinition {

    /** Logical widget identity, e.g. "productInfo", "pricingSection". */
    private String widgetKey;

    /**
     * Name of the {@link WidgetTemplate} to render (the FreeMarker template name).
     * If null, defaults to {@code widgetKey}.
     */
    private String templateName;

    /**
     * Key under which this widget's rendered JSON is placed in the final response.
     * If null, defaults to {@code widgetKey}. Matches the section names the frontend expects
     * (e.g. "productInfo", "productModifyOptions", "emiSection", "pricingSection").
     */
    private String outputKey;

    /** Render order (ascending). */
    private int order;

    /** Skip this widget entirely when false. */
    @Builder.Default
    private boolean enabled = true;

    public String resolveTemplateName() {
      return templateName != null ? templateName : widgetKey;
    }

    public String resolveOutputKey() {
      return outputKey != null ? outputKey : widgetKey;
    }
  }
}
