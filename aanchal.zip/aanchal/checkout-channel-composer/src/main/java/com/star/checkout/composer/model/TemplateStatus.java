package com.star.checkout.composer.model;

/**
 * Lifecycle state of a {@link WidgetTemplate} version.
 *
 * <p>At most one version per logical name should be {@link #ACTIVE} at a time. When a new version
 * is published it becomes ACTIVE and the previous ACTIVE is moved to {@link #INACTIVE} — it is
 * retained (never deleted) so it can serve as a fallback if the new version breaks.
 */
public enum TemplateStatus {
  /** The version the composer renders by default. */
  ACTIVE,
  /** A superseded or rolled-back version, kept for history and fallback. */
  INACTIVE
}
