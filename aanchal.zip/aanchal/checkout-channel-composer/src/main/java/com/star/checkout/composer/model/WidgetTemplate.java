package com.star.checkout.composer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * A single VERSION of a widget's FreeMarker source, stored in the database.
 *
 * <p>There are many documents per logical {@link #name} — one per {@link #version}. A change is
 * never an in-place edit; it is a new version. This lets the composer fall back to an older,
 * known-good version when the active one breaks.
 *
 * <ul>
 *   <li>{@code name} — logical template name used for lookup and {@code <#include>} resolution
 *       (e.g. "group-renewal/product-info.ftl", "common/group-premium-breakup.ftl").</li>
 *   <li>{@code version} — monotonically increasing per name.</li>
 *   <li>{@code status} — at most one {@link TemplateStatus#ACTIVE} per name.</li>
 *   <li>{@code lastKnownGood} — set true once this version has rendered successfully; used to
 *       pick a safe fallback.</li>
 * </ul>
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "widget_template")
@CompoundIndexes({
    @CompoundIndex(name = "name_version_unique", def = "{'name': 1, 'version': 1}", unique = true),
    @CompoundIndex(name = "name_status_idx", def = "{'name': 1, 'status': 1}")
})
public class WidgetTemplate {

  @Id
  private String id;

  /** Logical template name (shared across all versions). */
  @Indexed
  private String name;

  /** Version number, unique within a name. */
  private int version;

  /** The raw FreeMarker template source for this version. */
  private String content;

  /** Lifecycle state; at most one ACTIVE per name. */
  private TemplateStatus status;

  /** True once this version has rendered successfully at least once. */
  private boolean lastKnownGood;

  /** Optional human note, e.g. what changed in this version. */
  private String description;

  /** Epoch millis when this version was created. */
  private long createdAt;

  /** Epoch millis of last update; also feeds the FreeMarker loader's last-modified check. */
  private long lastModified;
}
