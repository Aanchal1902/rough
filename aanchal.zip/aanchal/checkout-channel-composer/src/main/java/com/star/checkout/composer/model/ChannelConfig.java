package com.star.checkout.composer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashMap;
import java.util.Map;

/**
 * Channel-specific configuration: redirection URLs, home URLs and any other
 * editable / feature-flag values that vary per channel (and optionally per core system / entity).
 *
 * <p>This document is looked up by {@code channelKey} and its values are merged into the
 * FreeMarker model under the {@code channelConfig} namespace so widget templates can read
 * e.g. {@code channelConfig.redirectionUrls.goToBackHomePageUrl}.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "channel_config")
public class ChannelConfig {

  @Id
  private String id;

  /** Business key used by the BFF to select the channel, e.g. "GROUP_RENEWAL". */
  @Indexed(unique = true)
  private String channelKey;

  /** Human-readable name for ops/debugging. */
  private String channelName;

  /** The core system this channel maps to (GROUP_RENEWAL, GROUP_FRESH, RETAIL, ...). */
  private String coreSystem;

  /** Redirection URLs, home URLs, exit URLs, etc. Free-form so channels can differ. */
  @Builder.Default
  private Map<String, Object> redirectionUrls = new HashMap<>();

  /**
   * Other editable / feature-flag configuration for the channel
   * (e.g. hideAdditionalCovers, default editable flags). Free-form on purpose.
   */
  @Builder.Default
  private Map<String, Object> properties = new HashMap<>();

  /** Toggle to disable a channel without deleting its config. */
  @Builder.Default
  private boolean enabled = true;
}
