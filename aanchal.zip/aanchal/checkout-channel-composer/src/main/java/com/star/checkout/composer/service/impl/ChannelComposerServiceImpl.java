package com.star.checkout.composer.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.star.checkout.composer.dto.ComposeRequest;
import com.star.checkout.composer.dto.ComposedResponse;
import com.star.checkout.composer.exception.ChannelComposerException;
import com.star.checkout.composer.model.ChannelConfig;
import com.star.checkout.composer.model.WidgetConfig;
import com.star.checkout.composer.model.WidgetTemplate;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.repository.WidgetConfigRepository;
import com.star.checkout.composer.service.ChannelComposerService;
import com.star.checkout.composer.service.TemplateNames;
import com.star.checkout.composer.service.TemplateRenderService;
import com.star.checkout.composer.service.WidgetTemplateVersionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Core composition engine.
 *
 * <ol>
 *   <li>Resolve {@link ChannelConfig} and {@link WidgetConfig} for the requested channel.</li>
 *   <li>Build the FreeMarker model root: the BFF's canonical data flattened to the top level,
 *       plus {@code channelConfig} and any request attributes.</li>
 *   <li>For each enabled widget (in order): render its ACTIVE version; if that breaks, render its
 *       last known-good version; if that also breaks, skip the widget. A single failing widget
 *       never breaks the page — the rest still compose.</li>
 * </ol>
 */
@Slf4j
@RequiredArgsConstructor
public class ChannelComposerServiceImpl implements ChannelComposerService {

  private final ChannelConfigRepository channelConfigRepository;
  private final WidgetConfigRepository widgetConfigRepository;
  private final TemplateRenderService templateRenderService;
  private final WidgetTemplateVersionService versionService;
  private final ObjectMapper objectMapper;

  @Override
  public ComposedResponse compose(ComposeRequest request) {
    validate(request);
    String channelKey = request.getChannelKey();
    log.info("Composing checkout page for channel '{}'", channelKey);

    ChannelConfig channelConfig = channelConfigRepository.findByChannelKeyAndEnabledTrue(channelKey)
        .orElseThrow(() -> new ChannelComposerException(
            "No enabled channel config found for channel '" + channelKey + "'"));

    WidgetConfig widgetConfig = widgetConfigRepository.findByChannelKey(channelKey)
        .orElseThrow(() -> new ChannelComposerException(
            "No widget config found for channel '" + channelKey + "'"));

    Map<String, Object> model = buildModel(request, channelConfig);

    ObjectNode result = objectMapper.createObjectNode();
    List<String> rendered = new ArrayList<>();
    List<String> fallback = new ArrayList<>();
    List<String> failed = new ArrayList<>();

    widgetConfig.getWidgets().stream()
        .filter(WidgetConfig.WidgetDefinition::isEnabled)
        .sorted(Comparator.comparingInt(WidgetConfig.WidgetDefinition::getOrder))
        .forEach(widget -> composeWidget(widget, model, result, rendered, fallback, failed));

    if (!failed.isEmpty()) {
      log.warn("Channel '{}' composed with {} failed widget(s): {}", channelKey, failed.size(), failed);
    }
    log.info("Composed channel '{}' -> rendered={}, fallback={}, failed={}",
        channelKey, rendered, fallback, failed);

    return ComposedResponse.builder()
        .data(result)
        .channelKey(channelKey)
        .renderedWidgets(rendered)
        .fallbackWidgets(fallback)
        .failedWidgets(failed)
        .build();
  }

  /**
   * Renders one widget resiliently: ACTIVE version first, then last known-good fallback, then skip.
   * Any exception is contained here so it cannot break sibling widgets or the overall response.
   */
  private void composeWidget(WidgetConfig.WidgetDefinition widget,
                             Map<String, Object> model,
                             ObjectNode result,
                             List<String> rendered,
                             List<String> fallback,
                             List<String> failed) {
    String name = widget.resolveTemplateName();
    String outputKey = widget.resolveOutputKey();

    // --- Attempt 1: the ACTIVE version ---
    Optional<WidgetTemplate> active = safeResolveActive(name);
    int activeVersion = active.map(WidgetTemplate::getVersion).orElse(-1);
    if (active.isPresent()) {
      try {
        Optional<JsonNode> fragment = renderVersion(name, activeVersion, model);
        versionService.markLastKnownGood(active.get());
        fragment.ifPresent(node -> result.set(outputKey, node));
        rendered.add(outputKey);
        return;
      } catch (Exception e) {
        log.warn("Widget '{}' active version v{} failed ({}). Attempting fallback...",
            widget.getWidgetKey(), activeVersion, e.getMessage());
      }
    } else {
      log.warn("Widget '{}' has no ACTIVE template '{}'. Attempting fallback...",
          widget.getWidgetKey(), name);
    }

    // --- Attempt 2: the last known-good fallback version (excluding the one that just failed) ---
    Optional<WidgetTemplate> fb = safeResolveFallback(name, activeVersion);
    if (fb.isPresent()) {
      try {
        Optional<JsonNode> fragment = renderVersion(name, fb.get().getVersion(), model);
        fragment.ifPresent(node -> result.set(outputKey, node));
        fallback.add(outputKey);
        log.info("Widget '{}' served from fallback version v{}", widget.getWidgetKey(), fb.get().getVersion());
        return;
      } catch (Exception e) {
        log.error("Widget '{}' fallback version v{} also failed ({}). Skipping widget.",
            widget.getWidgetKey(), fb.get().getVersion(), e.getMessage());
      }
    }

    // --- Give up on this widget only; the page still renders everything else. ---
    failed.add(outputKey);
  }

  /**
   * Renders a specific version and parses it to JSON.
   *
   * @return the parsed fragment, or empty if the template legitimately rendered blank
   *         (e.g. an entity-gated section) — a blank render is a success, not a failure.
   * @throws Exception if rendering fails or the output is not valid JSON (caller handles fallback).
   */
  private Optional<JsonNode> renderVersion(String name, int version, Map<String, Object> model) throws Exception {
    String pinnedName = TemplateNames.pinned(name, version);
    String text = templateRenderService.render(pinnedName, model);
    if (StringUtils.isBlank(text)) {
      return Optional.empty();
    }
    return Optional.of(objectMapper.readTree(text));
  }

  private Optional<WidgetTemplate> safeResolveActive(String name) {
    try {
      return versionService.resolveActive(name);
    } catch (Exception e) {
      log.warn("Failed to resolve ACTIVE template '{}': {}", name, e.getMessage());
      return Optional.empty();
    }
  }

  private Optional<WidgetTemplate> safeResolveFallback(String name, int failedVersion) {
    try {
      return versionService.resolveFallback(name, failedVersion);
    } catch (Exception e) {
      log.warn("Failed to resolve fallback for template '{}': {}", name, e.getMessage());
      return Optional.empty();
    }
  }

  /**
   * Flattens the canonical data to the model root so existing templates that reference top-level
   * fields (productInfo, masterPolicies, editableContext, groupPricingSection, ...) keep working,
   * then layers channelConfig and request attributes on top.
   */
  private Map<String, Object> buildModel(ComposeRequest request, ChannelConfig channelConfig) {
    Map<String, Object> model = new HashMap<>();

    Object data = request.getData();
    if (data != null) {
      if (data instanceof Map<?, ?> dataMap) {
        dataMap.forEach((k, v) -> model.put(String.valueOf(k), v));
      } else {
        // Convert the BFF POJO into a map so its properties are top-level in the model.
        Map<String, Object> asMap = objectMapper.convertValue(data, new TypeReference<>() {});
        model.putAll(asMap);
      }
    }

    // Channel config exposed under a dedicated namespace: channelConfig.redirectionUrls.xxx etc.
    Map<String, Object> channelConfigModel = new HashMap<>();
    channelConfigModel.put("channelKey", channelConfig.getChannelKey());
    channelConfigModel.put("channelName", channelConfig.getChannelName());
    channelConfigModel.put("coreSystem", channelConfig.getCoreSystem());
    channelConfigModel.put("redirectionUrls", channelConfig.getRedirectionUrls());
    if (channelConfig.getProperties() != null) {
      channelConfigModel.putAll(channelConfig.getProperties());
    }
    model.put("channelConfig", channelConfigModel);

    // Request-time overrides / extras win last.
    model.putAll(request.attributesOrEmpty());
    return model;
  }

  private void validate(ComposeRequest request) {
    if (request == null || StringUtils.isBlank(request.getChannelKey())) {
      throw new ChannelComposerException("ComposeRequest.channelKey is required");
    }
  }
}
