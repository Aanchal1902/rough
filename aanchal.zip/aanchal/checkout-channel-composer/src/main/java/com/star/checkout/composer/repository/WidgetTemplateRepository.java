package com.star.checkout.composer.repository;

import com.star.checkout.composer.model.TemplateStatus;
import com.star.checkout.composer.model.WidgetTemplate;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface WidgetTemplateRepository extends MongoRepository<WidgetTemplate, String> {

  /** Exact version lookup (used by the version-aware template loader for {@code name@version}). */
  Optional<WidgetTemplate> findByNameAndVersion(String name, int version);

  /**
   * The active version for a name. Uses findFirst + order-by so that even if two docs were
   * somehow left ACTIVE, the highest version wins rather than throwing.
   */
  Optional<WidgetTemplate> findFirstByNameAndStatusOrderByVersionDesc(String name, TemplateStatus status);

  /** The newest known-good version other than {@code excludedVersion} — the fallback target. */
  Optional<WidgetTemplate> findFirstByNameAndLastKnownGoodIsTrueAndVersionNotOrderByVersionDesc(
      String name, int excludedVersion);

  /** Highest existing version for a name (used when publishing the next version). */
  Optional<WidgetTemplate> findFirstByNameOrderByVersionDesc(String name);

  boolean existsByNameAndStatus(String name, TemplateStatus status);
}
