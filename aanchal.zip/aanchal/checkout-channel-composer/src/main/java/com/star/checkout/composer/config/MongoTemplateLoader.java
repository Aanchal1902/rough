package com.star.checkout.composer.config;

import com.star.checkout.composer.model.WidgetTemplate;
import com.star.checkout.composer.service.TemplateNames;
import com.star.checkout.composer.service.WidgetTemplateVersionService;
import freemarker.cache.TemplateLoader;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.Reader;
import java.io.StringReader;
import java.util.Optional;

/**
 * FreeMarker {@link TemplateLoader} that resolves widget templates from MongoDB, version-aware.
 *
 * <ul>
 *   <li>A bare name ({@code common/group-premium-breakup.ftl}, and the names used by
 *       {@code <#include>}) resolves to the ACTIVE version.</li>
 *   <li>A pinned name ({@code group-renewal/product-info.ftl@3}) resolves to that exact version —
 *       the composer uses this to render a specific active/fallback version.</li>
 * </ul>
 *
 * <p>Leading slashes are stripped so {@code <#include "/common/x.ftl">} and a stored name of
 * {@code common/x.ftl} match.
 */
@Slf4j
@RequiredArgsConstructor
public class MongoTemplateLoader implements TemplateLoader {

  private final WidgetTemplateVersionService versionService;

  @Override
  public Object findTemplateSource(String name) {
    String requested = normalise(name);

    Optional<WidgetTemplate> template;
    if (TemplateNames.isPinned(requested)) {
      String base = TemplateNames.baseName(requested);
      Integer version = TemplateNames.version(requested);
      template = version != null ? versionService.resolveVersion(base, version) : Optional.empty();
    } else {
      template = versionService.resolveActive(requested);
    }

    if (template.isEmpty()) {
      log.debug("No widget template resolved in Mongo for '{}'", requested);
      return null;
    }
    return template.get();
  }

  @Override
  public long getLastModified(Object templateSource) {
    return ((WidgetTemplate) templateSource).getLastModified();
  }

  @Override
  public Reader getReader(Object templateSource, String encoding) {
    return new StringReader(((WidgetTemplate) templateSource).getContent());
  }

  @Override
  public void closeTemplateSource(Object templateSource) {
    // Nothing to close for an in-memory document.
  }

  private String normalise(String name) {
    if (name == null) {
      return null;
    }
    return name.startsWith("/") ? name.substring(1) : name;
  }
}
