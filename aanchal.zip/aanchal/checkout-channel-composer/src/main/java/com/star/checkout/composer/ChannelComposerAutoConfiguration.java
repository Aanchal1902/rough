package com.star.checkout.composer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.star.checkout.composer.config.MongoTemplateLoader;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.repository.WidgetConfigRepository;
import com.star.checkout.composer.repository.WidgetTemplateRepository;
import com.star.checkout.composer.seed.WidgetTemplateSeeder;
import com.star.checkout.composer.service.ChannelComposerService;
import com.star.checkout.composer.service.TemplateRenderService;
import com.star.checkout.composer.service.WidgetTemplateVersionService;
import com.star.checkout.composer.service.impl.ChannelComposerServiceImpl;
import freemarker.template.Configuration;
import freemarker.template.TemplateExceptionHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import java.util.Locale;

/**
 * Auto-configuration entry point for the Checkout Channel Composer library.
 *
 * <p>Registered via {@code META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports}.
 * When the Checkout BFF puts this JAR on its classpath, all beans below are wired automatically.
 *
 * <p>Every bean uses explicit {@code @Bean} definitions (not component scanning) and is guarded
 * with {@link ConditionalOnMissingBean}. This is deliberate: the composer package sits under the
 * BFF's own scan root, so stereotype scanning would double-register beans. The conditions also let
 * the BFF override any bean by declaring its own.
 */
@Slf4j
@AutoConfiguration
@ConditionalOnClass(com.mongodb.client.MongoClient.class)
@EnableMongoRepositories(basePackageClasses = ChannelConfigRepository.class)
public class ChannelComposerAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public WidgetTemplateVersionService widgetTemplateVersionService(WidgetTemplateRepository widgetTemplateRepository) {
    return new WidgetTemplateVersionService(widgetTemplateRepository);
  }

  @Bean
  @ConditionalOnMissingBean
  public MongoTemplateLoader mongoTemplateLoader(WidgetTemplateVersionService widgetTemplateVersionService) {
    return new MongoTemplateLoader(widgetTemplateVersionService);
  }

  @Bean(name = "composerFreemarkerConfiguration")
  @ConditionalOnMissingBean(name = "composerFreemarkerConfiguration")
  public Configuration composerFreemarkerConfiguration(MongoTemplateLoader mongoTemplateLoader) {
    Configuration configuration = new Configuration(Configuration.VERSION_2_3_32);
    configuration.setTemplateLoader(mongoTemplateLoader);
    configuration.setDefaultEncoding("UTF-8");
    configuration.setLocale(Locale.ENGLISH);
    // Fail fast on template errors rather than emitting broken JSON.
    configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
    configuration.setLogTemplateExceptions(false);
    configuration.setWrapUncheckedExceptions(true);
    configuration.setFallbackOnNullLoopVariable(false);
    // Do not append locale suffixes (name_en_US.ftl) — it would mangle version-pinned names.
    configuration.setLocalizedLookup(false);
    // Numbers must not be formatted with grouping separators inside JSON.
    configuration.setNumberFormat("computer");
    // Templates change in Mongo at runtime; re-check the loader's lastModified every 5s.
    configuration.setTemplateUpdateDelayMilliseconds(5000);
    log.info("Initialised Channel Composer FreeMarker configuration (Mongo-backed template loader)");
    return configuration;
  }

  @Bean
  @ConditionalOnMissingBean
  public TemplateRenderService templateRenderService(Configuration composerFreemarkerConfiguration) {
    return new TemplateRenderService(composerFreemarkerConfiguration);
  }

  @Bean
  @ConditionalOnMissingBean
  public ChannelComposerService channelComposerService(ChannelConfigRepository channelConfigRepository,
                                                       WidgetConfigRepository widgetConfigRepository,
                                                       TemplateRenderService templateRenderService,
                                                       WidgetTemplateVersionService widgetTemplateVersionService,
                                                       ObjectMapper objectMapper) {
    return new ChannelComposerServiceImpl(channelConfigRepository, widgetConfigRepository,
        templateRenderService, widgetTemplateVersionService, objectMapper);
  }

  @Bean
  @ConditionalOnProperty(prefix = "composer.seed", name = "enabled", havingValue = "true")
  public WidgetTemplateSeeder widgetTemplateSeeder(WidgetTemplateVersionService widgetTemplateVersionService,
                                                   WidgetTemplateRepository widgetTemplateRepository,
                                                   ChannelConfigRepository channelConfigRepository,
                                                   WidgetConfigRepository widgetConfigRepository,
                                                   ObjectMapper objectMapper,
                                                   @Value("${composer.seed.overwrite:false}") boolean overwrite) {
    return new WidgetTemplateSeeder(widgetTemplateVersionService, widgetTemplateRepository,
        channelConfigRepository, widgetConfigRepository, objectMapper, overwrite);
  }
}
