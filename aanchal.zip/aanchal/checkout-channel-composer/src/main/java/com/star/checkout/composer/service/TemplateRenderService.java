package com.star.checkout.composer.service;

import com.star.checkout.composer.exception.ChannelComposerException;
import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.StringWriter;
import java.util.Map;

/**
 * Renders a single widget template (resolved from Mongo by name) against a model map,
 * returning the raw rendered text. Instantiated by {@code ChannelComposerAutoConfiguration}.
 */
@Slf4j
@RequiredArgsConstructor
public class TemplateRenderService {

  private final Configuration composerFreemarkerConfiguration;

  /**
   * @param templateName name of the widget template stored in Mongo (widget_template.name)
   * @param model        the FreeMarker data model (root)
   * @return the rendered template text (expected to be a JSON fragment)
   */
  public String render(String templateName, Map<String, Object> model) {
    try {
      Template template = composerFreemarkerConfiguration.getTemplate(templateName);
      StringWriter writer = new StringWriter();
      template.process(model, writer);
      return writer.toString();
    } catch (Exception e) {
      throw new ChannelComposerException(
          "Failed to render widget template '" + templateName + "': " + e.getMessage(), e);
    }
  }
}
