package com.star.checkout.composer.repository;

import com.star.checkout.composer.model.WidgetConfig;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface WidgetConfigRepository extends MongoRepository<WidgetConfig, String> {

  Optional<WidgetConfig> findByChannelKey(String channelKey);
}
