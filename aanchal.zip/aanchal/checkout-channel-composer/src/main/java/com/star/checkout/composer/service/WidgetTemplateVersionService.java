package com.star.checkout.composer.service;

import com.star.checkout.composer.model.TemplateStatus;
import com.star.checkout.composer.model.WidgetTemplate;
import com.star.checkout.composer.repository.WidgetTemplateRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

/**
 * Owns the versioning lifecycle of widget templates: resolving the active version, picking a
 * known-good fallback, marking a version good once it renders, and publishing new versions.
 *
 * <p>Instantiated by {@code ChannelComposerAutoConfiguration}.
 */
@Slf4j
@RequiredArgsConstructor
public class WidgetTemplateVersionService {

  private final WidgetTemplateRepository widgetTemplateRepository;

  /** The version the composer should try first. */
  public Optional<WidgetTemplate> resolveActive(String name) {
    return widgetTemplateRepository.findFirstByNameAndStatusOrderByVersionDesc(name, TemplateStatus.ACTIVE);
  }

  /** Exact version (used by the loader for {@code name@version}). */
  public Optional<WidgetTemplate> resolveVersion(String name, int version) {
    return widgetTemplateRepository.findByNameAndVersion(name, version);
  }

  /**
   * The newest known-good version to fall back to when {@code failedVersion} breaks.
   * Excludes the version that just failed so we never retry the same broken content.
   */
  public Optional<WidgetTemplate> resolveFallback(String name, int failedVersion) {
    return widgetTemplateRepository
        .findFirstByNameAndLastKnownGoodIsTrueAndVersionNotOrderByVersionDesc(name, failedVersion);
  }

  /** Records that a version rendered successfully, so it becomes eligible as a fallback. */
  public void markLastKnownGood(WidgetTemplate template) {
    if (template == null || template.isLastKnownGood()) {
      return;
    }
    template.setLastKnownGood(true);
    template.setLastModified(System.currentTimeMillis());
    widgetTemplateRepository.save(template);
    log.debug("Marked template '{}' v{} as last-known-good", template.getName(), template.getVersion());
  }

  /**
   * Publishes a new version of a template: inserts {@code max+1} as ACTIVE (unproven), and demotes
   * the previously active version to INACTIVE (kept as a fallback). This is the only way template
   * content changes — existing versions are immutable.
   */
  public WidgetTemplate publishNewVersion(String name, String content, String description) {
    int nextVersion = widgetTemplateRepository.findFirstByNameOrderByVersionDesc(name)
        .map(t -> t.getVersion() + 1)
        .orElse(1);

    widgetTemplateRepository.findFirstByNameAndStatusOrderByVersionDesc(name, TemplateStatus.ACTIVE)
        .ifPresent(current -> {
          current.setStatus(TemplateStatus.INACTIVE);
          current.setLastModified(System.currentTimeMillis());
          widgetTemplateRepository.save(current);
          log.info("Demoted template '{}' v{} to INACTIVE", name, current.getVersion());
        });

    long now = System.currentTimeMillis();
    WidgetTemplate published = WidgetTemplate.builder()
        .name(name)
        .version(nextVersion)
        .content(content)
        .description(description)
        .status(TemplateStatus.ACTIVE)
        .lastKnownGood(false)
        .createdAt(now)
        .lastModified(now)
        .build();
    WidgetTemplate saved = widgetTemplateRepository.save(published);
    log.info("Published template '{}' v{} as ACTIVE", name, nextVersion);
    return saved;
  }
}
