package com.star.checkout.composer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

import java.util.HashMap;
import java.util.Map;

/**
 * Input the Checkout BFF passes to {@code ChannelComposerService.compose(...)}.
 *
 * <p>Because the composer is a library called in-process, {@link #data} can be the BFF's own
 * canonical object (e.g. the assembled CheckoutResponse for Group Renewal) — no serialization
 * required. Its properties become the top-level FreeMarker model, exactly as the legacy
 * monolithic templates expect (e.g. {@code productInfo}, {@code masterPolicies},
 * {@code editableContext}, {@code groupPricingSection}).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComposeRequest {

  /** Selects the channel config + widget config, e.g. "GROUP_RENEWAL". Required. */
  private String channelKey;

  /**
   * The canonical checkout data assembled by the BFF from the core-system response.
   * May be any POJO or a Map; its fields are exposed at the root of the FreeMarker model.
   */
  private Object data;

  /**
   * Optional extra values merged into the model root (alongside {@code data}'s fields),
   * for anything the BFF wants to inject at composition time without baking it into {@code data}.
   */
  @Singular("attribute")
  private Map<String, Object> attributes;

  public Map<String, Object> attributesOrEmpty() {
    return attributes != null ? attributes : new HashMap<>();
  }
}
