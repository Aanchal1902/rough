package com.star.checkout.composer.repository;

import com.star.checkout.composer.model.ChannelConfig;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface ChannelConfigRepository extends MongoRepository<ChannelConfig, String> {

  Optional<ChannelConfig> findByChannelKeyAndEnabledTrue(String channelKey);

  Optional<ChannelConfig> findByChannelKey(String channelKey);
}
