package com.star.checkout.composer.service;

/**
 * Encoding of version-pinned template names shared by the composer and the Mongo template loader.
 *
 * <p>A bare name ("group-renewal/product-info.ftl") resolves to the ACTIVE version — this is what
 * {@code <#include>} statements use. A pinned name ("group-renewal/product-info.ftl@3") resolves to
 * that exact version — this is what the composer uses so it can control active-vs-fallback rendering.
 */
public final class TemplateNames {

  public static final String VERSION_DELIMITER = "@";

  private TemplateNames() {
  }

  public static String pinned(String name, int version) {
    return name + VERSION_DELIMITER + version;
  }

  public static boolean isPinned(String name) {
    return name != null && name.lastIndexOf(VERSION_DELIMITER) > 0;
  }

  public static String baseName(String name) {
    int idx = name.lastIndexOf(VERSION_DELIMITER);
    return idx > 0 ? name.substring(0, idx) : name;
  }

  /** @return the pinned version, or {@code null} if the name is not pinned / not numeric. */
  public static Integer version(String name) {
    int idx = name.lastIndexOf(VERSION_DELIMITER);
    if (idx <= 0) {
      return null;
    }
    try {
      return Integer.parseInt(name.substring(idx + VERSION_DELIMITER.length()));
    } catch (NumberFormatException e) {
      return null;
    }
  }
}
