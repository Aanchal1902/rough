package com.star.checkout.composer.seed;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.star.checkout.composer.model.ChannelConfig;
import com.star.checkout.composer.model.TemplateStatus;
import com.star.checkout.composer.model.WidgetConfig;
import com.star.checkout.composer.model.WidgetTemplate;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.repository.WidgetConfigRepository;
import com.star.checkout.composer.repository.WidgetTemplateRepository;
import com.star.checkout.composer.service.WidgetTemplateVersionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.util.StreamUtils;

import java.nio.charset.StandardCharsets;

/**
 * Loads seed data (channel config, widget config, and per-widget FTLs) from the JAR's
 * {@code classpath:seed/**} into MongoDB on startup.
 *
 * <p>Disabled by default. Enable ONLY in local/dev or a one-off bootstrap run:
 * <pre>
 *   composer.seed.enabled=true       # run the seeder at all
 *   composer.seed.overwrite=false    # if true, replace existing docs; otherwise only insert missing ones
 * </pre>
 * In real environments the config + templates are managed directly in Mongo, so this stays off.
 */
@Slf4j
@RequiredArgsConstructor
public class WidgetTemplateSeeder implements CommandLineRunner {

  private static final String TEMPLATE_ROOT = "seed/templates/";

  private final WidgetTemplateVersionService versionService;
  private final WidgetTemplateRepository widgetTemplateRepository;
  private final ChannelConfigRepository channelConfigRepository;
  private final WidgetConfigRepository widgetConfigRepository;
  private final ObjectMapper objectMapper;
  private final boolean overwrite;

  @Override
  public void run(String... args) throws Exception {
    log.info("Channel Composer seeder starting (overwrite={})", overwrite);
    seedTemplates();
    seedChannelConfig();
    seedWidgetConfig();
    log.info("Channel Composer seeder finished");
  }

  private void seedTemplates() throws Exception {
    PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
    Resource[] resources = resolver.getResources("classpath*:" + TEMPLATE_ROOT + "**/*.ftl");
    for (Resource resource : resources) {
      String name = templateName(resource);
      if (name == null) {
        continue;
      }
      boolean hasActive = widgetTemplateRepository.existsByNameAndStatus(name, TemplateStatus.ACTIVE);
      if (hasActive && !overwrite) {
        log.info("Template '{}' already has an ACTIVE version; skipping (overwrite=false)", name);
        continue;
      }
      String content = StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
      // Publishing bumps to the next version and demotes the previous active (kept as fallback).
      // Seed templates are the trusted baseline, so mark them known-good immediately.
      WidgetTemplate published = versionService.publishNewVersion(name, content,
          hasActive ? "seeded (overwrite)" : "seeded baseline");
      versionService.markLastKnownGood(published);
      log.info("Seeded template '{}' as v{}", name, published.getVersion());
    }
  }

  private void seedChannelConfig() throws Exception {
    PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
    Resource[] resources = resolver.getResources("classpath*:seed/channel/*.json");
    for (Resource resource : resources) {
      ChannelConfig config = objectMapper.readValue(resource.getInputStream(), ChannelConfig.class);
      boolean exists = channelConfigRepository.findByChannelKey(config.getChannelKey()).isPresent();
      if (exists && !overwrite) {
        log.info("Channel config '{}' already present; skipping", config.getChannelKey());
        continue;
      }
      channelConfigRepository.findByChannelKey(config.getChannelKey())
          .ifPresent(existing -> config.setId(existing.getId()));
      channelConfigRepository.save(config);
      log.info("Seeded channel config '{}'", config.getChannelKey());
    }
  }

  private void seedWidgetConfig() throws Exception {
    PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
    Resource[] resources = resolver.getResources("classpath*:seed/widget/*.json");
    for (Resource resource : resources) {
      WidgetConfig config = objectMapper.readValue(resource.getInputStream(), WidgetConfig.class);
      boolean exists = widgetConfigRepository.findByChannelKey(config.getChannelKey()).isPresent();
      if (exists && !overwrite) {
        log.info("Widget config '{}' already present; skipping", config.getChannelKey());
        continue;
      }
      widgetConfigRepository.findByChannelKey(config.getChannelKey())
          .ifPresent(existing -> config.setId(existing.getId()));
      widgetConfigRepository.save(config);
      log.info("Seeded widget config '{}'", config.getChannelKey());
    }
  }

  /** Derives the template name from the resource path after {@code seed/templates/}. */
  private String templateName(Resource resource) throws Exception {
    String uri = resource.getURI().toString();
    int idx = uri.indexOf(TEMPLATE_ROOT);
    if (idx < 0) {
      return null;
    }
    return uri.substring(idx + TEMPLATE_ROOT.length());
  }
}
