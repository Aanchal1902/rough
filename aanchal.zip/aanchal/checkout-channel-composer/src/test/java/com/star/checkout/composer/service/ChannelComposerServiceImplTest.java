package com.star.checkout.composer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.star.checkout.composer.dto.ComposeRequest;
import com.star.checkout.composer.dto.ComposedResponse;
import com.star.checkout.composer.exception.ChannelComposerException;
import com.star.checkout.composer.model.ChannelConfig;
import com.star.checkout.composer.model.TemplateStatus;
import com.star.checkout.composer.model.WidgetConfig;
import com.star.checkout.composer.model.WidgetTemplate;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.repository.WidgetConfigRepository;
import com.star.checkout.composer.service.impl.ChannelComposerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ChannelComposerServiceImplTest {

  private static final String CHANNEL = "GROUP_RENEWAL";

  @Mock
  private ChannelConfigRepository channelConfigRepository;
  @Mock
  private WidgetConfigRepository widgetConfigRepository;
  @Mock
  private TemplateRenderService templateRenderService;
  @Mock
  private WidgetTemplateVersionService versionService;

  private ChannelComposerServiceImpl service;

  @BeforeEach
  void setUp() {
    service = new ChannelComposerServiceImpl(
        channelConfigRepository, widgetConfigRepository, templateRenderService, versionService, new ObjectMapper());
  }

  @Test
  void composesEnabledWidgetsInOrderFromActiveVersions() {
    stubChannel();
    stubWidgets(
        widget("productInfo", "product-info.ftl", "productInfo", 2, true),
        widget("header", "header.ftl", "pageHeaderSection", 1, true));

    stubActive("header.ftl", 3);
    stubActive("product-info.ftl", 1);
    when(templateRenderService.render(eq("header.ftl@3"), anyMap())).thenReturn("{\"title\":\"Checkout\"}");
    when(templateRenderService.render(eq("product-info.ftl@1"), anyMap())).thenReturn("{\"title\":\"Star Group Health\"}");

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).containsExactly("pageHeaderSection", "productInfo");
    assertThat(response.getFallbackWidgets()).isEmpty();
    assertThat(response.getFailedWidgets()).isEmpty();
    assertThat(response.isDegraded()).isFalse();
    assertThat(response.getData().get("pageHeaderSection").get("title").asText()).isEqualTo("Checkout");
  }

  @Test
  void fallsBackToLastKnownGoodWhenActiveVersionBreaks() {
    stubChannel();
    stubWidgets(widget("pricing", "pricing.ftl", "pricingSection", 1, true));

    stubActive("pricing.ftl", 5);
    when(templateRenderService.render(eq("pricing.ftl@5"), anyMap())).thenReturn("{ this is : broken json");
    stubFallback("pricing.ftl", 5, 4);
    when(templateRenderService.render(eq("pricing.ftl@4"), anyMap())).thenReturn("{\"total\":100}");

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).isEmpty();
    assertThat(response.getFallbackWidgets()).containsExactly("pricingSection");
    assertThat(response.getFailedWidgets()).isEmpty();
    assertThat(response.isDegraded()).isTrue();
    assertThat(response.getData().get("pricingSection").get("total").asInt()).isEqualTo(100);
  }

  @Test
  void oneBrokenWidgetDoesNotBreakTheRestOfThePage() {
    stubChannel();
    stubWidgets(
        widget("header", "header.ftl", "pageHeaderSection", 1, true),
        widget("pricing", "pricing.ftl", "pricingSection", 2, true),
        widget("productInfo", "product-info.ftl", "productInfo", 3, true));

    // header + productInfo render fine
    stubActive("header.ftl", 1);
    stubActive("product-info.ftl", 1);
    when(templateRenderService.render(eq("header.ftl@1"), anyMap())).thenReturn("{\"title\":\"Checkout\"}");
    when(templateRenderService.render(eq("product-info.ftl@1"), anyMap())).thenReturn("{\"title\":\"P\"}");

    // pricing active AND fallback both fail -> widget skipped, page survives
    stubActive("pricing.ftl", 2);
    when(templateRenderService.render(eq("pricing.ftl@2"), anyMap())).thenThrow(new RuntimeException("boom"));
    stubFallback("pricing.ftl", 2, 1);
    when(templateRenderService.render(eq("pricing.ftl@1"), anyMap())).thenThrow(new RuntimeException("also boom"));

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).containsExactly("pageHeaderSection", "productInfo");
    assertThat(response.getFailedWidgets()).containsExactly("pricingSection");
    assertThat(response.getData().has("pricingSection")).isFalse();
    assertThat(response.getData().has("pageHeaderSection")).isTrue();
    assertThat(response.getData().has("productInfo")).isTrue();
  }

  @Test
  void widgetWithNoActiveAndNoFallbackIsSkipped() {
    stubChannel();
    stubWidgets(widget("ghost", "ghost.ftl", "ghost", 1, true));
    when(versionService.resolveActive("ghost.ftl")).thenReturn(Optional.empty());
    when(versionService.resolveFallback(eq("ghost.ftl"), eq(-1))).thenReturn(Optional.empty());

    ComposedResponse response = compose();

    assertThat(response.getFailedWidgets()).containsExactly("ghost");
    assertThat(response.getRenderedWidgets()).isEmpty();
  }

  @Test
  void blankRenderIsTreatedAsSuccessAndSkippedFromOutput() {
    stubChannel();
    stubWidgets(widget("tnc", "tnc.ftl", "termsAndConditionsSection", 1, true));
    stubActive("tnc.ftl", 1);
    // e.g. non-customer entity -> the gated template renders only whitespace
    when(templateRenderService.render(eq("tnc.ftl@1"), anyMap())).thenReturn("   \n  ");

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).containsExactly("termsAndConditionsSection");
    assertThat(response.getFailedWidgets()).isEmpty();
    assertThat(response.getData().has("termsAndConditionsSection")).isFalse();
  }

  @Test
  void skipsDisabledWidgets() {
    stubChannel();
    stubWidgets(
        widget("header", "header.ftl", "pageHeaderSection", 1, true),
        widget("auto", "auto.ftl", "autoRenewalSection", 2, false));
    stubActive("header.ftl", 1);
    when(templateRenderService.render(eq("header.ftl@1"), anyMap())).thenReturn("{\"title\":\"Checkout\"}");

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).containsExactly("pageHeaderSection");
  }

  @Test
  void throwsWhenChannelConfigMissing() {
    when(channelConfigRepository.findByChannelKeyAndEnabledTrue(CHANNEL)).thenReturn(Optional.empty());
    assertThatThrownBy(this::compose)
        .isInstanceOf(ChannelComposerException.class)
        .hasMessageContaining("channel config");
  }

  @Test
  void throwsWhenChannelKeyBlank() {
    assertThatThrownBy(() -> service.compose(ComposeRequest.builder().build()))
        .isInstanceOf(ChannelComposerException.class)
        .hasMessageContaining("channelKey is required");
  }

  // --- helpers ---

  private ComposedResponse compose() {
    return service.compose(ComposeRequest.builder().channelKey(CHANNEL).data(Map.of()).build());
  }

  private void stubChannel() {
    ChannelConfig channelConfig = ChannelConfig.builder()
        .channelKey(CHANNEL).channelName("Group Renewal").coreSystem(CHANNEL).enabled(true).build();
    lenient().when(channelConfigRepository.findByChannelKeyAndEnabledTrue(CHANNEL))
        .thenReturn(Optional.of(channelConfig));
  }

  private void stubWidgets(WidgetConfig.WidgetDefinition... defs) {
    WidgetConfig widgetConfig = WidgetConfig.builder().channelKey(CHANNEL).widgets(List.of(defs)).build();
    when(widgetConfigRepository.findByChannelKey(CHANNEL)).thenReturn(Optional.of(widgetConfig));
  }

  private void stubActive(String name, int version) {
    WidgetTemplate t = WidgetTemplate.builder()
        .name(name).version(version).status(TemplateStatus.ACTIVE).lastKnownGood(true)
        .content("<ignored, render is mocked>").build();
    when(versionService.resolveActive(name)).thenReturn(Optional.of(t));
  }

  private void stubFallback(String name, int failedVersion, int fallbackVersion) {
    WidgetTemplate t = WidgetTemplate.builder()
        .name(name).version(fallbackVersion).status(TemplateStatus.INACTIVE).lastKnownGood(true)
        .content("<ignored, render is mocked>").build();
    when(versionService.resolveFallback(name, failedVersion)).thenReturn(Optional.of(t));
  }

  private WidgetConfig.WidgetDefinition widget(String key, String template, String outputKey, int order, boolean enabled) {
    return WidgetConfig.WidgetDefinition.builder()
        .widgetKey(key).templateName(template).outputKey(outputKey).order(order).enabled(enabled).build();
  }
}
