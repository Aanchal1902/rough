/*
 * seed-mongo.js — pure-DB seeding for the Checkout Channel Composer.
 *
 * A standalone alternative to the Java WidgetTemplateSeeder: it populates the same three
 * collections (channel_config, widget_config, widget_template) directly, without running the
 * BFF or the composer JAR. Hand it to a DBA, run it in CI, or use it for local bootstrap.
 *
 * It reads the bundled seed data straight from src/main/resources/seed so it never drifts from
 * the templates the library ships with.
 *
 * ---------------------------------------------------------------------------------------------
 * USAGE (run with mongosh — it bundles Node, so require('fs') is available):
 *
 *   # from the project root (checkout-channel-composer/)
 *   mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
 *
 *   # overwrite existing docs / publish a new template version even if one already exists
 *   OVERWRITE=true mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
 *
 *   # point at a seed dir other than the default (absolute or relative to your CWD)
 *   SEED_DIR=/path/to/seed mongosh "mongodb://host/db" scripts/seed-mongo.js
 *
 * The target database comes from the connection string — the script writes to the current `db`.
 * ---------------------------------------------------------------------------------------------
 */

const fs = require('fs');

const CONFIG = {
  // Directory containing channel/, widget/, templates/. Default assumes CWD = project root.
  seedDir: (process.env && process.env.SEED_DIR) || 'src/main/resources/seed',
  // false = only insert what's missing (like composer.seed.overwrite=false).
  // true  = re-upsert configs and publish a NEW template version even when an ACTIVE one exists.
  overwrite: !!(process.env && process.env.OVERWRITE && process.env.OVERWRITE !== 'false'),
};

const TEMPLATES_ROOT = CONFIG.seedDir + '/templates';

// --- small fs helpers (avoid require('path') so this stays maximally portable) --------------

function readUtf8(p) {
  return fs.readFileSync(p, 'utf8');
}

function listFilesRecursive(dir, suffix) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = dir + '/' + entry.name;
    if (entry.isDirectory()) {
      out.push.apply(out, listFilesRecursive(full, suffix));
    } else if (entry.name.endsWith(suffix)) {
      out.push(full);
    }
  }
  return out;
}

/** Logical template name = path after templates/, normalised to forward slashes. */
function templateNameOf(fullPath) {
  let rel = fullPath.substring(TEMPLATES_ROOT.length);
  rel = rel.replace(/\\/g, '/').replace(/^\/+/, '');
  return rel;
}

// --- indexes: mirror the @Document / @CompoundIndexes on the Java models --------------------

function ensureIndexes() {
  db.widget_template.createIndex({ name: 1, version: 1 }, { unique: true, name: 'name_version_unique' });
  db.widget_template.createIndex({ name: 1, status: 1 }, { name: 'name_status_idx' });
  db.channel_config.createIndex({ channelKey: 1 }, { unique: true, name: 'channelKey_unique' });
  db.widget_config.createIndex({ channelKey: 1 }, { unique: true, name: 'channelKey_unique' });
  print('Ensured indexes on widget_template, channel_config, widget_config');
}

// --- versioned publish: mirrors WidgetTemplateVersionService.publishNewVersion + markLastKnownGood

function publishVersion(name, content, description) {
  const coll = db.widget_template;
  const hasActive = coll.countDocuments({ name: name, status: 'ACTIVE' }) > 0;
  if (hasActive && !CONFIG.overwrite) {
    print("  skip template '" + name + "' (ACTIVE version exists, overwrite=false)");
    return;
  }

  const top = coll.find({ name: name }).sort({ version: -1 }).limit(1).toArray()[0];
  const nextVersion = top ? top.version + 1 : 1;

  // Demote the current ACTIVE version to INACTIVE (kept as a fallback candidate).
  if (hasActive) {
    coll.updateMany(
      { name: name, status: 'ACTIVE' },
      { $set: { status: 'INACTIVE', lastModified: Date.now() } });
  }

  const now = Date.now();
  coll.insertOne({
    name: name,
    version: nextVersion,
    content: content,
    description: description,
    status: 'ACTIVE',
    // Seed templates are the trusted baseline, so they are known-good immediately —
    // this is what makes them eligible as a fallback for future broken versions.
    lastKnownGood: true,
    createdAt: now,
    lastModified: now,
  });
  print("  published template '" + name + "' v" + nextVersion + " (ACTIVE, lastKnownGood)");
}

// --- config upsert: mirrors WidgetTemplateSeeder.seedChannelConfig / seedWidgetConfig --------

function upsertConfig(collName, doc) {
  const filter = { channelKey: doc.channelKey };
  const exists = db[collName].countDocuments(filter) > 0;
  if (exists && !CONFIG.overwrite) {
    print("  skip " + collName + " '" + doc.channelKey + "' (exists, overwrite=false)");
    return;
  }
  db[collName].replaceOne(filter, doc, { upsert: true });
  print("  upserted " + collName + " '" + doc.channelKey + "'");
}

function seedConfigDir(subdir, collName) {
  const dir = CONFIG.seedDir + '/' + subdir;
  if (!fs.existsSync(dir)) {
    print('No ' + subdir + ' dir at ' + dir + ' — skipping');
    return;
  }
  for (const file of listFilesRecursive(dir, '.json')) {
    upsertConfig(collName, JSON.parse(readUtf8(file)));
  }
}

// --- run ------------------------------------------------------------------------------------

print('Channel Composer seed starting (seedDir=' + CONFIG.seedDir + ', overwrite=' + CONFIG.overwrite + ')');

ensureIndexes();

print('Seeding templates from ' + TEMPLATES_ROOT);
for (const file of listFilesRecursive(TEMPLATES_ROOT, '.ftl')) {
  publishVersion(templateNameOf(file), readUtf8(file), 'seeded baseline');
}

print('Seeding channel_config');
seedConfigDir('channel', 'channel_config');

print('Seeding widget_config');
seedConfigDir('widget', 'widget_config');

print('Channel Composer seed finished');
