/*
 * seed-mongo.js — pure-DB seeding for the Checkout Channel Composer.
 *
 * Populates the three collections (channel_config, widgets, channel_widget_config)
 * directly without running the BFF or the composer JAR.
 *
 * ---------------------------------------------------------------------------------------------
 * USAGE (run with mongosh — it bundles Node, so require('fs') is available):
 *
 *   # from the project root (checkout-channel-composer/)
 *   mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
 *
 *   # overwrite existing docs
 *   OVERWRITE=true mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
 *
 *   # point at a seed dir other than the default (absolute or relative to your CWD)
 *   SEED_DIR=/path/to/seed mongosh "mongodb://host/db" scripts/seed-mongo.js
 *
 * The target database comes from the connection string — the script writes to the current `db`.
 * ---------------------------------------------------------------------------------------------
 */

const fs = require('fs');

const CONFIG = {
  // Directory containing channel/, widget/, channel-widget/. Default assumes CWD = project root.
  seedDir: (process.env && process.env.SEED_DIR) || 'src/main/resources/seed',
  // false = only insert what's missing.
  // true  = re-upsert configs even when they exist.
  overwrite: !!(process.env && process.env.OVERWRITE && process.env.OVERWRITE !== 'false'),
};

// --- small fs helpers (avoid require('path') so this stays maximally portable) --------------

function readUtf8(p) {
  return fs.readFileSync(p, 'utf8');
}

function listFilesRecursive(dir, suffix) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = dir + '/' + entry.name;
    if (entry.isDirectory()) {
      out.push.apply(out, listFilesRecursive(full, suffix));
    } else if (entry.name.endsWith(suffix)) {
      out.push(full);
    }
  }
  return out;
}

// --- indexes: mirror the @Document / @CompoundIndexes on the Java models --------------------

function ensureIndexes() {
  // Channel config indexes
  db.channel_config.createIndex(
    {
      channel: 1,
      journey: 1,
      journeyFlow: 1,
      flowVariant: 1,
      persona: 1,
      checkout: 1,
      step: 1
    },
    { unique: true, name: 'channel_journey_flow_unique' }
  );

  // Channel widget config indexes
  db.channel_widget_config.createIndex({ widgetId: 1, version: 1 }, { unique: true, name: 'widgetId_version_unique' });

  // Widgets config indexes
  db.widgets.createIndex({ channelId: 1, subChannelId: 1 }, { unique: true, name: 'channel_subChannel_unique' });

  print('Ensured indexes on channel_config, channel_widget_config, widgets');
}

// --- config upsert functions --------

function upsertChannelConfig(doc) {
  let filter, identifier;

  // Use new structure if available
  if (doc.channel && doc.journey) {
    filter = {
      channel: doc.channel,
      journey: doc.journey,
      journeyFlow: doc.journeyFlow || 'DEFAULT',
      flowVariant: doc.flowVariant || 'DEFAULT',
      persona: doc.persona || 'customer',
      checkout: doc.checkout || 'STANDARD',
      step: doc.step || 'CHECKOUT'
    };
    identifier = doc.channel + '/' + doc.journey;
  } else {
    // Fallback to legacy structure
    filter = { channelKey: doc.channelKey };
    identifier = doc.channelKey;
  }

  const exists = db.channel_config.countDocuments(filter) > 0;
  if (exists && !CONFIG.overwrite) {
    print("  skip channel_config '" + identifier + "' (exists, overwrite=false)");
    return;
  }
  db.channel_config.replaceOne(filter, doc, { upsert: true });
  print("  upserted channel_config '" + identifier + "'");
}

function upsertWidgets(doc) {
  const filter = { channelId: doc.channelId, subChannelId: doc.subChannelId };
  const identifier = doc.channelId + '/' + doc.subChannelId;

  const exists = db.widgets.countDocuments(filter) > 0;
  if (exists && !CONFIG.overwrite) {
    print("  skip widgets '" + identifier + "' (exists, overwrite=false)");
    return;
  }
  db.widgets.replaceOne(filter, doc, { upsert: true });
  print("  upserted widgets '" + identifier + "'");
}

function upsertChannelWidgetConfig(doc) {
  const filter = { widgetId: doc.widgetId, version: doc.version };
  const identifier = doc.widgetId + '@' + doc.version;

  const exists = db.channel_widget_config.countDocuments(filter) > 0;
  if (exists && !CONFIG.overwrite) {
    print("  skip channel_widget_config '" + identifier + "' (exists, overwrite=false)");
    return;
  }
  db.channel_widget_config.replaceOne(filter, doc, { upsert: true });
  print("  upserted channel_widget_config '" + identifier + "'");
}

function seedConfigDir(subdir, collName) {
  const dir = CONFIG.seedDir + '/' + subdir;
  if (!fs.existsSync(dir)) {
    print('No ' + subdir + ' dir at ' + dir + ' — skipping');
    return;
  }
  for (const file of listFilesRecursive(dir, '.json')) {
    const doc = JSON.parse(readUtf8(file));
    if (collName === 'channel_config') {
      upsertChannelConfig(doc);
    } else if (collName === 'widgets') {
      upsertWidgets(doc);
    } else if (collName === 'channel_widget_config') {
      upsertChannelWidgetConfig(doc);
    }
  }
}

// --- run ------------------------------------------------------------------------------------

print('Channel Composer seed starting (seedDir=' + CONFIG.seedDir + ', overwrite=' + CONFIG.overwrite + ')');

ensureIndexes();

print('Seeding channel_config');
seedConfigDir('channel', 'channel_config');

print('Seeding widgets');
seedConfigDir('widget', 'widgets');

print('Seeding channel_widget_config');
seedConfigDir('channel-widget', 'channel_widget_config');

print('Channel Composer seed finished');
