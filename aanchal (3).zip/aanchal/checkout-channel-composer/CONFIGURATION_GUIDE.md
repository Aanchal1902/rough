# Simplified Channel Configuration Guide

This document explains the simplified 3-table structure for the Checkout Channel Composer.

## Overview

The system uses a simplified 3-table structure:
1. **channel_config** - Channel routing and configuration
2. **widgets** - Widget composition and templates 
3. **channel_widget_config** - Individual widget configurations (optional)

## Database Structure

### 1. Channel Configuration (`channel_config`)

Defines channel routing based on journey flows, variants, personas, and checkout types:

```json
{
  "channel": "atom",
  "journey": "banca-group-renewal", 
  "journeyFlow": "DEFAULT",
  "flowVariant": "DEFAULT",
  "persona": "customer",
  "checkout": "STANDARD",
  "step": "CHECKOUT",
  "redirectionConfig": {
    "homePage": {
      "url": "/home",
      "params": {},
      "enabled": true
    },
    "backButton": {
      "enabled": true,
      "url": "/review/${orderId}",
      "params": {}
    }
  },
  "editableConfig": {
    "sumInsured": {
      "isEditable": false,
      "isDisabled": true,
      "isRedirection": false,
      "redirectionAttributes": {}
    },
    "autoRenewal": {
      "isEditable": true,
      "isDisabled": false,
      "isRedirection": false,
      "redirectionAttributes": {}
    }
  },
  "active": true,
  "version": "1.0.0"
}
```

### 2. Widgets Configuration (`widgets`)

Contains widget composition and inline templates:

```json
{
  "channelId": "atom",
  "subChannelId": "banca-group-renewal",
  "coreSystem": "group-renewal",
  "journey": "renewal",
  "role": "customer",
  "step": "checkout", 
  "status": "ACTIVE",
  "configVersion": 1,
  "widgets": [
    {
      "capability": "planDetails",
      "widget": "PLAN_DETAILS_WIDGET",
      "version": "1.0.0",
      "enabled": true,
      "order": 1,
      "template": "{ \"title\": \"${planDetails.title!\\\"Plan Details\\\"}\", \"planType\": \"${planDetails.planType!\\\"-\\\"}\", \"coverage\": \"${planDetails.coverage!\\\"-\\\"}\" }"
    },
    {
      "capability": "paymentPreference", 
      "widget": "PAYMENT_PREFERENCE_WIDGET",
      "version": "1.0.0",
      "enabled": true,
      "order": 8,
      "template": "{ \"mode\": \"${paymentPreference.mode!\\\"\\\"}\", \"frequency\": \"${paymentPreference.frequency!\\\"\\\"}\", \"editable\": \"${channelConfig.editableConfig.paymentPreference.isEditable!false}\" }"
    }
  ]
}
```

#### Key Fields:
- **template**: JSON template with variable substitution (${variable!default})
- **capability**: Widget functionality identifier
- **widget**: Widget implementation identifier
- **order**: Rendering order

### 3. Channel Widget Configuration (`channel_widget_config`) - Optional

For reusable widget configurations:

```json
{
  "widgetId": "PRODUCT_INFO_CARD",
  "version": "1.0.0",
  "ftl": {
    "title": "${productInfo.productName!\"-\"}",
    "image": "${productInfo.imageUrl!\"-\"}"
  },
  "active": true,
  "properties": {
    "displayMode": "detailed",
    "allowEdit": false
  }
}
```

## API Usage

### ComposeRequest

Simple API with required channel and journey:

```java
ComposeRequest request = ComposeRequest.builder()
    .channel("atom")
    .journey("banca-group-renewal")
    .journeyFlow("DEFAULT")         // Optional, defaults to "DEFAULT"
    .flowVariant("DEFAULT")         // Optional, defaults to "DEFAULT"
    .persona("customer")            // Optional, defaults to "customer"
    .checkout("STANDARD")           // Optional, defaults to "STANDARD"
    .step("CHECKOUT")              // Optional, defaults to "CHECKOUT"
    .subChannelId("banca-group-renewal")  // Optional, defaults to journey
    .data(checkoutData)
    .build();
```

## Template Processing

The system supports simple template variable substitution:

- **Basic**: `${variable}` - Direct variable access
- **Nested**: `${object.property}` - Object property access  
- **Default**: `${variable!"default"}` - Default value if variable is null/missing

Examples:
```json
{
  "title": "${planDetails.title!\"Plan Details\"}",
  "amount": "${sumInsured.amount!0}",
  "editable": "${channelConfig.editableConfig.sumInsured.isEditable!false}"
}
```

## Configuration Resolution

1. **Channel Config**: Exact match on all dimensions, fallback to channel + journey
2. **Widgets**: Channel + subChannelId with status = "ACTIVE"

## Database Indexes

```javascript
// Channel config compound index
db.channel_config.createIndex({
  channel: 1, journey: 1, journeyFlow: 1, 
  flowVariant: 1, persona: 1, checkout: 1, step: 1
}, { unique: true });

// Widgets index
db.widgets.createIndex({ channelId: 1, subChannelId: 1 }, { unique: true });

// Channel widget config index
db.channel_widget_config.createIndex({ widgetId: 1, version: 1 }, { unique: true });
```

## Examples

Sample seed data files:
- [Channel Config](src/main/resources/seed/channel/atom-banca-group-renewal-channel.json)
- [Widgets Config](src/main/resources/seed/widget/atom-banca-group-renewal-widgets.json)  
- [Widget Config](src/main/resources/seed/channel-widget/product-info-card-widget.json)

## Seeding Data

```bash
# From project root
mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js

# With overwrite
OVERWRITE=true mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
```

## Migration from Complex Structure

The simplified structure eliminates:
- Widget versioning and fallback complexity
- FreeMarker template compilation
- Separate template storage

Benefits:
- Simpler deployment and management
- Direct template editing in database
- Reduced complexity while maintaining flexibility