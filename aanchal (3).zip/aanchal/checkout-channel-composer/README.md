# Checkout Channel Composer

A Spring Boot starter library for dynamic checkout page composition with routing capabilities:
- **Channel Configuration**: Journey-based routing and editable UI controls
- **Widget Composition**: Ordered widget rendering with inline JSON templates  
- **Routing Service**: Tells BFF which downstream services to call
- **Template Processing**: Simple variable substitution in JSON templates

## Core Concepts

### Simplified 3-Table Architecture

| Collection               | Model                  | Purpose |
|--------------------------|------------------------|---------|
| `channel_config`         | `ChannelConfig`        | Channel routing, redirection URLs, editable configs, downstream service URLs |
| `widgets`                | `Widgets`              | Widget composition with inline JSON templates for each channel/journey |
| `channel_widget_config`  | `ChannelWidgetConfig`  | Reusable widget configurations (optional) |

### Routing + Composition Flow

```
BFF → checkoutRoutingService.getRoutingInfo() → downstream service URL
BFF → HTTP call to downstream service → raw response  
BFF → channelComposerService.compose(rawResponse) → final JSON with FTL processing
```

## API

### 1. Routing Service

```java
@Autowired
private CheckoutRoutingService checkoutRoutingService;

// Check if routing is enabled
boolean enabled = checkoutRoutingService.isRoutingEnabled("atom", "banca-group-renewal");

// Get downstream service info
RoutingInfo info = checkoutRoutingService.getRoutingInfo("atom", "banca-group-renewal", null);
// Returns: { serviceBaseUrl: "http://group-renewal-svc:8080", checkoutEndpoint: "/api/v1/checkout" }
```

### 2. Composition Service

```java
@Autowired
private ChannelComposerService channelComposerService;

ComposeRequest request = ComposeRequest.builder()
    .channel("atom")
    .journey("banca-group-renewal")
    .data(rawDownstreamResponse)  // Raw response from downstream service
    .build();

ComposedResponse response = channelComposerService.compose(request);
// response.getData() = JsonNode with processed templates
```

## Template Processing

### Simple Variable Substitution

Templates use `${variable!default}` syntax:

```json
{
  "template": "{ \"title\": \"${planDetails.title!\\\"Plan Details\\\"}\", \"amount\": \"${sumInsured.amount!0}\" }"
}
```

**Processing:**
- `${planDetails.title}` → Looks up `data.planDetails.title`
- `!\"Plan Details\"` → Default value if variable is missing
- `${channelConfig.editableConfig.sumInsured.isEditable!false}` → Nested object access

## Configuration Examples

### Channel Config
```json
{
  "channel": "atom",
  "journey": "banca-group-renewal",
  "serviceConfig": {
    "baseUrl": "http://group-renewal-svc:8080",
    "checkoutEndpoint": "/api/v1/checkout",
    "enabled": true
  },
  "editableConfig": {
    "sumInsured": { "isEditable": false },
    "autoRenewal": { "isEditable": true }
  }
}
```

### Widgets Config
```json
{
  "channelId": "atom", 
  "subChannelId": "banca-group-renewal",
  "status": "ACTIVE",
  "widgets": [
    {
      "capability": "planDetails",
      "order": 1,
      "enabled": true,
      "template": "{ \"title\": \"${planDetails.title!\\\"Plan Details\\\"}\" }"
    }
  ]
}
```

## Data Seeding

### MongoDB Script (Recommended)

```bash
# From project root
mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js

# Overwrite existing
OVERWRITE=true mongosh "mongodb://localhost:27017/checkout" scripts/seed-mongo.js
```

### Seed Data Layout

```
src/main/resources/seed/
├── channel/               # ChannelConfig JSON files
│   └── atom-banca-group-renewal-channel.json
├── widget/                # Widgets JSON files  
│   └── atom-banca-group-renewal-widgets.json
└── channel-widget/        # ChannelWidgetConfig JSON files (optional)
    └── product-info-card-widget.json
```

## BFF Integration

See `BFF_INTEGRATION_GUIDE.md` for complete integration example.

**Quick Integration:**
```java
// 1. Check routing
if (checkoutRoutingService.isRoutingEnabled(channel, journey)) {
    // 2. Get service URL  
    RoutingInfo info = checkoutRoutingService.getRoutingInfo(channel, journey, null);
    
    // 3. Call downstream service
    Object rawResponse = restTemplate.postForEntity(info.getFullServiceUrl(), request, Object.class);
    
    // 4. Compose final response
    ComposedResponse final = channelComposerService.compose(
        ComposeRequest.builder().channel(channel).journey(journey).data(rawResponse).build()
    );
} else {
    // Legacy flow
}
```

## Benefits

- **Gradual Rollout**: Enable routing per channel/journey with database toggle
- **Zero Downtime**: Automatic fallback to legacy flow on errors  
- **Centralized Config**: All routing and templates in database
- **Simple Templates**: JSON with variable substitution, no complex FreeMarker
- **Composable**: Mix and match widgets per channel configuration
