package com.star.checkout.composer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.repository.ChannelWidgetConfigRepository;
import com.star.checkout.composer.repository.WidgetsRepository;
import com.star.checkout.composer.service.ChannelComposerService;
import com.star.checkout.composer.service.CheckoutRoutingService;
import com.star.checkout.composer.service.impl.ChannelComposerServiceImpl;
import com.star.checkout.composer.service.impl.CheckoutRoutingServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * Auto-configuration entry point for the simplified Checkout Channel Composer library.
 *
 * <p>Registered via {@code META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports}.
 * When the Checkout BFF puts this JAR on its classpath, all beans below are wired automatically.
 *
 * <p>Every bean uses explicit {@code @Bean} definitions (not component scanning) and is guarded
 * with {@link ConditionalOnMissingBean}. This is deliberate: the composer package sits under the
 * BFF's own scan root, so stereotype scanning would double-register beans. The conditions also let
 * the BFF override any bean by declaring its own.
 */
@Slf4j
@AutoConfiguration
@ConditionalOnClass(com.mongodb.client.MongoClient.class)
@EnableMongoRepositories(basePackageClasses = ChannelConfigRepository.class)
public class ChannelComposerAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public ChannelComposerService channelComposerService(ChannelConfigRepository channelConfigRepository,
                                                       ChannelWidgetConfigRepository channelWidgetConfigRepository,
                                                       WidgetsRepository widgetsRepository,
                                                       ObjectMapper objectMapper) {
    return new ChannelComposerServiceImpl(channelConfigRepository, channelWidgetConfigRepository,
        widgetsRepository, objectMapper);
  }

  @Bean
  @ConditionalOnMissingBean
  public CheckoutRoutingService checkoutRoutingService(ChannelConfigRepository channelConfigRepository) {
    return new CheckoutRoutingServiceImpl(channelConfigRepository);
  }
}
