package com.star.checkout.composer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

/**
 * Routing information returned to BFF for downstream service calls.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RoutingInfo {

  /** Whether routing is enabled for this channel/journey. */
  @Builder.Default
  private boolean routingEnabled = false;

  /** Base URL of the downstream service (e.g., "http://group-renewal-svc:8080"). */
  private String serviceBaseUrl;

  /** Specific endpoint path for checkout operations (e.g., "/api/v1/checkout"). */
  @Builder.Default
  private String checkoutEndpoint = "/checkout";

  /** HTTP timeout in milliseconds for the downstream call. */
  @Builder.Default
  private Integer timeoutMs = 30000;

  /** Additional headers to send to downstream service. */
  @Builder.Default
  private Map<String, String> headers = new HashMap<>();

  /** Complete URL for BFF to call (baseUrl + endpoint). */
  public String getFullServiceUrl() {
    return serviceBaseUrl + checkoutEndpoint;
  }

  /** Whether the routing info is valid and complete. */
  public boolean isValid() {
    return routingEnabled && serviceBaseUrl != null && !serviceBaseUrl.trim().isEmpty();
  }
}