package com.star.checkout.composer.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Result of composition: the assembled widget JSON that the BFF returns to the frontend, plus
 * metadata describing how resilient rendering went.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComposedResponse {

  /** The final composed document — an object keyed by each successfully rendered widget's outputKey. */
  private JsonNode data;

  /** The channel this response was composed for. */
  private String channelKey;

  /** Output keys of widgets that rendered from their ACTIVE version, in order. */
  private List<String> renderedWidgets;

  /** Output keys of widgets whose active version broke and were served from a fallback version. */
  private List<String> fallbackWidgets;

  /** Output keys of widgets that could not render at all (active and fallback both failed) and were skipped. */
  private List<String> failedWidgets;

  /** True when at least one widget fell back or failed — the page still rendered, but degraded. */
  public boolean isDegraded() {
    return (fallbackWidgets != null && !fallbackWidgets.isEmpty())
        || (failedWidgets != null && !failedWidgets.isEmpty());
  }
}
