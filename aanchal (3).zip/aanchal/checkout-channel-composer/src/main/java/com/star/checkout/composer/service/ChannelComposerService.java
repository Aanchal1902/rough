package com.star.checkout.composer.service;

import com.star.checkout.composer.dto.ComposeRequest;
import com.star.checkout.composer.dto.ComposedResponse;

/**
 * Public entry point of the Checkout Channel Composer library.
 *
 * <p>The Checkout BFF autowires this bean and calls {@link #compose(ComposeRequest)} with the
 * canonical checkout data plus the channel key. The composer looks up the channel's widget
 * configuration and per-widget FTLs from MongoDB, renders each enabled widget, and returns the
 * assembled widget JSON. There is no REST layer — this is an in-process library call.
 */
public interface ChannelComposerService {

  ComposedResponse compose(ComposeRequest request);
}
