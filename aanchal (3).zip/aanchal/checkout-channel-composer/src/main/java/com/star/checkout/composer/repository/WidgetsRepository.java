package com.star.checkout.composer.repository;

import com.star.checkout.composer.model.Widgets;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for managing {@link Widgets} documents.
 */
@Repository
public interface WidgetsRepository extends MongoRepository<Widgets, String> {

  /**
   * Find widgets configuration by channel ID and sub-channel ID.
   *
   * @param channelId    The channel identifier
   * @param subChannelId The sub-channel identifier
   * @return Optional containing the configuration if found
   */
  Optional<Widgets> findByChannelIdAndSubChannelId(String channelId, String subChannelId);

  /**
   * Find all configurations for a channel ID.
   *
   * @param channelId The channel identifier
   * @return List of configurations
   */
  List<Widgets> findByChannelId(String channelId);

  /**
   * Find all active configurations.
   *
   * @param status The configuration status
   * @return List of configurations with the specified status
   */
  List<Widgets> findByStatus(String status);

  /**
   * Find configurations by core system.
   *
   * @param coreSystem The core system identifier
   * @return List of configurations
   */
  List<Widgets> findByCoreSystem(String coreSystem);

  /**
   * Find active configurations by channel and sub-channel.
   *
   * @param channelId    The channel identifier
   * @param subChannelId The sub-channel identifier
   * @param status       The status
   * @return Optional containing the active configuration
   */
  Optional<Widgets> findByChannelIdAndSubChannelIdAndStatus(String channelId, String subChannelId, String status);
}