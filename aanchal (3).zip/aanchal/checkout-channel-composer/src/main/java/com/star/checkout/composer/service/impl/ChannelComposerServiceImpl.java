package com.star.checkout.composer.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.star.checkout.composer.dto.ComposeRequest;
import com.star.checkout.composer.dto.ComposedResponse;
import com.star.checkout.composer.exception.ChannelComposerException;
import com.star.checkout.composer.model.ChannelConfig;
import com.star.checkout.composer.model.ChannelWidgetConfig;
import com.star.checkout.composer.model.Widgets;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.repository.ChannelWidgetConfigRepository;
import com.star.checkout.composer.repository.WidgetsRepository;
import com.star.checkout.composer.service.ChannelComposerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Simplified composition engine using 3-table structure.
 *
 * <ol>
 *   <li>Resolve {@link ChannelConfig} and {@link Widgets} for the requested channel/journey.</li>
 *   <li>Build the FreeMarker model root: the BFF's canonical data flattened to the top level,
 *       plus {@code channelConfig} and any request attributes.</li>
 *   <li>For each enabled widget (in order): render its template directly from the widgets config.</li>
 * </ol>
 */
@Slf4j
@RequiredArgsConstructor
public class ChannelComposerServiceImpl implements ChannelComposerService {

  private final ChannelConfigRepository channelConfigRepository;
  private final ChannelWidgetConfigRepository channelWidgetConfigRepository;
  private final WidgetsRepository widgetsRepository;
  private final ObjectMapper objectMapper;

  @Override
  public ComposedResponse compose(ComposeRequest request) {
    validate(request);

    ChannelConfig channelConfig = resolveChannelConfig(request);
    Widgets widgets = resolveWidgets(request);

    String identifier = request.getChannel() + "/" + request.getJourney();
    log.info("Composing checkout page for identifier '{}'", identifier);

    Map<String, Object> model = buildModel(request, channelConfig);

    ObjectNode result = objectMapper.createObjectNode();
    List<String> rendered = new ArrayList<>();
    List<String> failed = new ArrayList<>();

    widgets.getWidgets().stream()
        .filter(Widgets.WidgetDefinition::isEnabled)
        .sorted(Comparator.comparingInt(Widgets.WidgetDefinition::getOrder))
        .forEach(widget -> composeWidget(widget, model, result, rendered, failed));

    if (!failed.isEmpty()) {
      log.warn("Channel '{}' composed with {} failed widget(s): {}", identifier, failed.size(), failed);
    }
    log.info("Composed channel '{}' -> rendered={}, failed={}",
        identifier, rendered, failed);

    return ComposedResponse.builder()
        .data(result)
        .channelKey(identifier)
        .renderedWidgets(rendered)
        .fallbackWidgets(new ArrayList<>()) // No fallback in simplified structure
        .failedWidgets(failed)
        .build();
  }

  /**
   * Resolve channel configuration.
   */
  private ChannelConfig resolveChannelConfig(ComposeRequest request) {
    Optional<ChannelConfig> config = channelConfigRepository
        .findByChannelAndJourneyAndJourneyFlowAndFlowVariantAndPersonaAndCheckoutAndStepAndActiveTrue(
            request.getChannel(),
            request.getJourney(),
            request.getJourneyFlow(),
            request.getFlowVariant(),
            request.getPersona(),
            request.getCheckout(),
            request.getStep());

    if (config.isPresent()) {
      return config.get();
    }

    // Fallback to simpler lookup
    config = channelConfigRepository.findByChannelAndJourneyAndActiveTrue(
        request.getChannel(), request.getJourney());
    if (config.isPresent()) {
      return config.get();
    }

    throw new ChannelComposerException("No channel configuration found for " +
        request.getChannel() + "/" + request.getJourney());
  }

  /**
   * Resolve widgets configuration.
   */
  private Widgets resolveWidgets(ComposeRequest request) {
    String subChannelId = request.getEffectiveSubChannelId();

    Optional<Widgets> config = widgetsRepository.findByChannelIdAndSubChannelIdAndStatus(
        request.getChannel(), subChannelId, "ACTIVE");

    if (config.isPresent()) {
      return config.get();
    }

    throw new ChannelComposerException("No widgets configuration found for " +
        request.getChannel() + "/" + subChannelId);
  }

  /**
   * Renders one widget directly from its template content.
   */
  private void composeWidget(Widgets.WidgetDefinition widget,
                             Map<String, Object> model,
                             ObjectNode result,
                             List<String> rendered,
                             List<String> failed) {
    String outputKey = widget.resolveOutputKey();

    try {
      // Check if we have template content
      if (StringUtils.isBlank(widget.getTemplate())) {
        log.warn("Widget '{}' has no template content, skipping", widget.getCapability());
        failed.add(outputKey);
        return;
      }

      // Render template directly
      String templateContent = processTemplate(widget.getTemplate(), model);

      if (StringUtils.isBlank(templateContent)) {
        // Empty render is OK, just don't include in output
        rendered.add(outputKey);
        return;
      }

      // Parse as JSON and add to result
      JsonNode fragment = objectMapper.readTree(templateContent);
      result.set(outputKey, fragment);
      rendered.add(outputKey);

    } catch (Exception e) {
      log.error("Widget '{}' failed to render: {}", widget.getCapability(), e.getMessage());
      failed.add(outputKey);
    }
  }

  /**
   * Simple template processing - replace ${variable} patterns with model values.
   * This is a simplified version of FreeMarker processing.
   */
  private String processTemplate(String template, Map<String, Object> model) {
    String result = template;

    // Simple pattern matching for ${variable.property!"default"} and ${variable!"default"}
    java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\\$\\{([^}]+)\\}");
    java.util.regex.Matcher matcher = pattern.matcher(template);

    while (matcher.find()) {
      String expression = matcher.group(1);
      String replacement = evaluateExpression(expression, model);
      result = result.replace(matcher.group(0), replacement);
    }

    return result;
  }

  /**
   * Evaluate a template expression like "productInfo.productName!"-"
   */
  private String evaluateExpression(String expression, Map<String, Object> model) {
    try {
      // Handle default values (expression!"default")
      String[] parts = expression.split("!", 2);
      String mainExpression = parts[0];
      String defaultValue = parts.length > 1 ? parts[1].replaceAll("^\"|\"$", "") : "";

      // Navigate the model using dot notation
      String[] pathParts = mainExpression.split("\\.");
      Object current = model;

      for (String part : pathParts) {
        if (current instanceof Map<?, ?> map) {
          current = map.get(part);
        } else if (current != null) {
          // Use reflection to get property
          try {
            current = current.getClass().getMethod("get" + capitalize(part)).invoke(current);
          } catch (Exception e) {
            current = null;
            break;
          }
        } else {
          current = null;
          break;
        }
      }

      return current != null ? current.toString() : defaultValue;
    } catch (Exception e) {
      log.warn("Failed to evaluate expression '{}': {}", expression, e.getMessage());
      return "";
    }
  }

  private String capitalize(String str) {
    return str.substring(0, 1).toUpperCase() + str.substring(1);
  }

  /**
   * Build the FreeMarker model from request data and channel config.
   */
  private Map<String, Object> buildModel(ComposeRequest request, ChannelConfig channelConfig) {
    Map<String, Object> model = new HashMap<>();

    Object data = request.getData();
    if (data != null) {
      if (data instanceof Map<?, ?> dataMap) {
        dataMap.forEach((k, v) -> model.put(String.valueOf(k), v));
      } else {
        // Convert the BFF POJO into a map so its properties are top-level in the model.
        Map<String, Object> asMap = objectMapper.convertValue(data, new TypeReference<>() {});
        model.putAll(asMap);
      }
    }

    // Channel config exposed under a dedicated namespace
    Map<String, Object> channelConfigModel = buildChannelConfigModel(channelConfig);
    model.put("channelConfig", channelConfigModel);

    // Request-time overrides / extras win last.
    model.putAll(request.attributesOrEmpty());
    return model;
  }

  /**
   * Build channel config model from the new structure.
   */
  private Map<String, Object> buildChannelConfigModel(ChannelConfig channelConfig) {
    Map<String, Object> channelConfigModel = new HashMap<>();

    channelConfigModel.put("channel", channelConfig.getChannel());
    channelConfigModel.put("journey", channelConfig.getJourney());
    channelConfigModel.put("journeyFlow", channelConfig.getJourneyFlow());
    channelConfigModel.put("flowVariant", channelConfig.getFlowVariant());
    channelConfigModel.put("persona", channelConfig.getPersona());
    channelConfigModel.put("checkout", channelConfig.getCheckout());
    channelConfigModel.put("step", channelConfig.getStep());
    channelConfigModel.put("version", channelConfig.getVersion());

    // Redirection config
    if (channelConfig.getRedirectionConfig() != null) {
      channelConfigModel.put("redirectionConfig", channelConfig.getRedirectionConfig());
    }

    // Editable config
    if (channelConfig.getEditableConfig() != null) {
      channelConfigModel.put("editableConfig", channelConfig.getEditableConfig());
    }

    return channelConfigModel;
  }

  private void validate(ComposeRequest request) {
    if (request == null) {
      throw new ChannelComposerException("ComposeRequest is required");
    }

    if (StringUtils.isBlank(request.getChannel()) || StringUtils.isBlank(request.getJourney())) {
      throw new ChannelComposerException("Both channel and journey are required");
    }
  }
}
