package com.star.checkout.composer.repository;

import com.star.checkout.composer.model.ChannelWidgetConfig;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for managing {@link ChannelWidgetConfig} documents.
 */
@Repository
public interface ChannelWidgetConfigRepository extends MongoRepository<ChannelWidgetConfig, String> {

  /**
   * Find widget configuration by widget ID and version.
   *
   * @param widgetId The widget identifier
   * @param version  The widget version
   * @return Optional containing the configuration if found
   */
  Optional<ChannelWidgetConfig> findByWidgetIdAndVersion(String widgetId, String version);

  /**
   * Find all active configurations for a widget ID.
   *
   * @param widgetId The widget identifier
   * @return List of active configurations
   */
  List<ChannelWidgetConfig> findByWidgetIdAndActiveTrue(String widgetId);

  /**
   * Find the latest version for a widget ID.
   *
   * @param widgetId The widget identifier
   * @return Optional containing the latest configuration if found
   */
  Optional<ChannelWidgetConfig> findTopByWidgetIdAndActiveTrueOrderByVersionDesc(String widgetId);

  /**
   * Find all active widget configurations.
   *
   * @return List of all active configurations
   */
  List<ChannelWidgetConfig> findByActiveTrue();
}