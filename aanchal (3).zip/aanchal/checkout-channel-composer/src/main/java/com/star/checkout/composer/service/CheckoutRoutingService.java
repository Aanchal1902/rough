package com.star.checkout.composer.service;

import com.star.checkout.composer.dto.RoutingInfo;

/**
 * Service for providing routing information to BFF for downstream service calls.
 */
public interface CheckoutRoutingService {

  /**
   * Get routing information for downstream service based on channel/journey configuration.
   * BFF will use this information to determine which downstream service to call.
   *
   * @param channel The channel identifier (e.g., "atom", "web")
   * @param journey The journey identifier (e.g., "banca-group-renewal")
   * @param subChannelId The sub-channel identifier for routing (optional, defaults to journey)
   * @return RoutingInfo containing downstream service URL and configuration
   */
  RoutingInfo getRoutingInfo(String channel, String journey, String subChannelId);

  /**
   * Check if routing is enabled for the given channel/journey combination.
   *
   * @param channel The channel identifier
   * @param journey The journey identifier
   * @return true if routing should be used, false to use legacy flow
   */
  boolean isRoutingEnabled(String channel, String journey);
}