package com.star.checkout.composer.repository;

import com.star.checkout.composer.model.ChannelConfig;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for managing {@link ChannelConfig} documents.
 */
@Repository
public interface ChannelConfigRepository extends MongoRepository<ChannelConfig, String> {

  /**
   * Find active configuration by channel, journey, and flow parameters.
   *
   * @param channel      The channel identifier
   * @param journey      The journey identifier
   * @param journeyFlow  The journey flow
   * @param flowVariant  The flow variant
   * @param persona      The user persona
   * @param checkout     The checkout type
   * @param step         The current step
   * @return Optional containing the configuration if found
   */
  Optional<ChannelConfig> findByChannelAndJourneyAndJourneyFlowAndFlowVariantAndPersonaAndCheckoutAndStepAndActiveTrue(
      String channel, String journey, String journeyFlow, String flowVariant, String persona, String checkout, String step);

  /**
   * Find configuration by channel and journey with default flows.
   *
   * @param channel The channel identifier
   * @param journey The journey identifier
   * @return Optional containing the configuration if found
   */
  Optional<ChannelConfig> findByChannelAndJourneyAndActiveTrue(String channel, String journey);

  /**
   * Find all active configurations for a channel.
   *
   * @param channel The channel identifier
   * @return List of active configurations
   */
  List<ChannelConfig> findByChannelAndActiveTrue(String channel);

  /**
   * Find all active configurations.
   *
   * @return List of all active configurations
   */
  List<ChannelConfig> findByActiveTrue();

  // Backward compatibility methods - deprecated
  @Deprecated
  Optional<ChannelConfig> findByChannelKeyAndEnabledTrue(String channelKey);

  @Deprecated
  Optional<ChannelConfig> findByChannelKey(String channelKey);
}
