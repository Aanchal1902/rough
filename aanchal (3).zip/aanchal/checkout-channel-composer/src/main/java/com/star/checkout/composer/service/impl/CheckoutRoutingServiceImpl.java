package com.star.checkout.composer.service.impl;

import com.star.checkout.composer.dto.RoutingInfo;
import com.star.checkout.composer.exception.ChannelComposerException;
import com.star.checkout.composer.model.ChannelConfig;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.service.CheckoutRoutingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Implementation of routing service that provides downstream service URLs to BFF.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CheckoutRoutingServiceImpl implements CheckoutRoutingService {

  private final ChannelConfigRepository channelConfigRepository;

  @Override
  public RoutingInfo getRoutingInfo(String channel, String journey, String subChannelId) {
    log.info("Getting routing info for channel: {}, journey: {}, subChannelId: {}",
             channel, journey, subChannelId);

    try {
      ChannelConfig channelConfig = resolveChannelConfig(channel, journey);

      if (channelConfig.getServiceConfig() == null || !channelConfig.getServiceConfig().isEnabled()) {
        log.info("Routing not enabled for channel: {}, journey: {}", channel, journey);
        return RoutingInfo.builder()
            .routingEnabled(false)
            .build();
      }

      ChannelConfig.ServiceConfig serviceConfig = channelConfig.getServiceConfig();

      return RoutingInfo.builder()
          .routingEnabled(true)
          .serviceBaseUrl(serviceConfig.getBaseUrl())
          .checkoutEndpoint(serviceConfig.getCheckoutEndpoint())
          .timeoutMs(serviceConfig.getTimeoutMs())
          .headers(serviceConfig.getHeaders())
          .build();

    } catch (Exception e) {
      log.error("Error getting routing info for {}/{}: {}", channel, journey, e.getMessage());
      return RoutingInfo.builder()
          .routingEnabled(false)
          .build();
    }
  }

  @Override
  public boolean isRoutingEnabled(String channel, String journey) {
    try {
      RoutingInfo routingInfo = getRoutingInfo(channel, journey, null);
      return routingInfo.isValid();
    } catch (Exception e) {
      log.warn("Error checking routing status for {}/{}: {}", channel, journey, e.getMessage());
      return false;
    }
  }

  /**
   * Resolve channel configuration with same logic as compose service.
   */
  private ChannelConfig resolveChannelConfig(String channel, String journey) {
    // Try exact match with defaults first
    Optional<ChannelConfig> config = channelConfigRepository
        .findByChannelAndJourneyAndJourneyFlowAndFlowVariantAndPersonaAndCheckoutAndStepAndActiveTrue(
            channel, journey, "DEFAULT", "DEFAULT", "customer", "STANDARD", "CHECKOUT");

    if (config.isPresent()) {
      return config.get();
    }

    // Fallback to simpler lookup
    config = channelConfigRepository.findByChannelAndJourneyAndActiveTrue(channel, journey);
    if (config.isPresent()) {
      return config.get();
    }

    throw new ChannelComposerException("No channel configuration found for " + channel + "/" + journey);
  }
}