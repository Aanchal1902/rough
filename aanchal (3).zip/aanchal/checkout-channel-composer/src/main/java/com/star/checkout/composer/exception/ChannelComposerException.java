package com.star.checkout.composer.exception;

/**
 * Thrown when composition cannot complete: unknown channel, missing widget config,
 * missing template, or a template that renders to invalid JSON.
 */
public class ChannelComposerException extends RuntimeException {

  public ChannelComposerException(String message) {
    super(message);
  }

  public ChannelComposerException(String message, Throwable cause) {
    super(message, cause);
  }
}
