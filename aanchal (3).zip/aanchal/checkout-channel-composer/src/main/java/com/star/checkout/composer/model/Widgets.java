package com.star.checkout.composer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

/**
 * Simplified widgets configuration that combines widget composition and template management.
 *
 * <p>This document defines which widgets should be rendered for a specific channel/sub-channel,
 * their order, versions, capabilities, and template content.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "widgets")
@CompoundIndexes({
    @CompoundIndex(name = "channel_subChannel_unique",
                   def = "{'channelId': 1, 'subChannelId': 1}",
                   unique = true)
})
public class Widgets {

  @Id
  private String id;

  /** Channel identifier (e.g. "atom", "web"). */
  private String channelId;

  /** Sub-channel identifier (e.g. "banca-group-renewal", "retail-fresh"). */
  private String subChannelId;

  /** Core system this configuration applies to. */
  private String coreSystem;

  /** Journey type (e.g. "renewal", "fresh"). */
  private String journey;

  /** User role (e.g. "customer", "agent"). */
  private String role;

  /** Current step (e.g. "checkout", "review"). */
  private String step;

  /** Configuration status (e.g. "ACTIVE", "INACTIVE"). */
  @Builder.Default
  private String status = "ACTIVE";

  /** Configuration version number. */
  @Builder.Default
  private Integer configVersion = 1;

  /** Ordered list of widgets for this configuration. */
  @Builder.Default
  private List<WidgetDefinition> widgets = new ArrayList<>();

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class WidgetDefinition {

    /** Widget capability (e.g. "planDetails", "proposerDetails"). */
    private String capability;

    /** Widget identifier (e.g. "PLAN_DETAILS_WIDGET"). */
    private String widget;

    /** Widget version. */
    @Builder.Default
    private String version = "1.0.0";

    /** Whether this widget is enabled. */
    @Builder.Default
    private boolean enabled = true;

    /** Render order (ascending). */
    private Integer order;

    /** FreeMarker template content for this widget. */
    private String template;

    /**
     * Resolved template name for rendering.
     * Uses capability as the template identifier.
     */
    public String resolveTemplateName() {
      return capability != null ? capability : widget;
    }

    /**
     * Resolved output key for the composed response.
     * Uses capability as the output key.
     */
    public String resolveOutputKey() {
      return capability;
    }
  }
}