package com.star.checkout.composer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration for individual widget instances with specific FTL templates and properties.
 *
 * <p>This document represents the configuration of a specific widget, including its
 * FreeMarker template configuration and any widget-specific properties.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "channel_widget_config")
@CompoundIndexes({
    @CompoundIndex(name = "widgetId_version_unique",
                   def = "{'widgetId': 1, 'version': 1}",
                   unique = true)
})
public class ChannelWidgetConfig {

  @Id
  private String id;

  /** Unique widget identifier (e.g. "PRODUCT_INFO_CARD", "PLAN_DETAILS_WIDGET"). */
  private String widgetId;

  /** Widget configuration version. */
  @Builder.Default
  private String version = "1.0.0";

  /** FreeMarker template configuration. */
  @Builder.Default
  private FtlConfig ftl = new FtlConfig();

  /** Whether this widget configuration is active. */
  @Builder.Default
  private boolean active = true;

  /** Additional widget properties (extensible). */
  @Builder.Default
  private Map<String, Object> properties = new HashMap<>();

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class FtlConfig {
    /** Template expression for title. */
    private String title;

    /** Template expression for image URL. */
    private String image;

    /** Template expression for description. */
    private String description;

    /** Additional FTL properties (extensible). */
    @Builder.Default
    private Map<String, String> additionalProperties = new HashMap<>();
  }
}