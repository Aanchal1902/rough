package com.star.checkout.composer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

import java.util.HashMap;
import java.util.Map;

/**
 * Input the Checkout BFF passes to {@code ChannelComposerService.compose(...)}.
 *
 * <p>The composer uses the channel and journey to lookup configuration and widgets.
 * The data object's properties become the top-level FreeMarker model for template rendering.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComposeRequest {

  /** Channel identifier (e.g. "atom", "web"). Required. */
  private String channel;

  /** Journey identifier (e.g. "banca-group-renewal", "retail-fresh"). Required. */
  private String journey;

  /** Journey flow variant (e.g. "DEFAULT", "SIMPLIFIED"). */
  @Builder.Default
  private String journeyFlow = "DEFAULT";

  /** Flow variant within the journey flow (e.g. "DEFAULT", "PREMIUM"). */
  @Builder.Default
  private String flowVariant = "DEFAULT";

  /** User persona/role (e.g. "customer", "agent", "admin"). */
  @Builder.Default
  private String persona = "customer";

  /** Checkout type (e.g. "STANDARD", "EXPRESS", "QUICK"). */
  @Builder.Default
  private String checkout = "STANDARD";

  /** Current step in the checkout flow (e.g. "CHECKOUT", "REVIEW", "PAYMENT"). */
  @Builder.Default
  private String step = "CHECKOUT";

  /** Sub-channel identifier for widget config lookup. Defaults to journey if not provided. */
  private String subChannelId;

  /**
   * The canonical checkout data assembled by the BFF from the core-system response.
   * May be any POJO or a Map; its fields are exposed at the root of the FreeMarker model.
   */
  private Object data;

  /**
   * Optional extra values merged into the model root (alongside {@code data}'s fields),
   * for anything the BFF wants to inject at composition time without baking it into {@code data}.
   */
  @Singular("attribute")
  private Map<String, Object> attributes;

  public Map<String, Object> attributesOrEmpty() {
    return attributes != null ? attributes : new HashMap<>();
  }

  /**
   * Get the effective sub-channel ID, defaulting to journey if not explicitly set.
   */
  public String getEffectiveSubChannelId() {
    return subChannelId != null ? subChannelId : journey;
  }
}
