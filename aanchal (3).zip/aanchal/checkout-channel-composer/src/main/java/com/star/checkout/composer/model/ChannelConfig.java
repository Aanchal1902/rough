package com.star.checkout.composer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashMap;
import java.util.Map;

/**
 * Channel-specific configuration for checkout flow with journey-based routing.
 *
 * <p>This document defines the configuration for a specific channel, journey, and checkout flow
 * including redirection URLs, editable configurations, and flow variants.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "channel_config")
@CompoundIndexes({
    @CompoundIndex(name = "channel_journey_flow_unique",
                   def = "{'channel': 1, 'journey': 1, 'journeyFlow': 1, 'flowVariant': 1, 'persona': 1, 'checkout': 1, 'step': 1}",
                   unique = true)
})
public class ChannelConfig {

  @Id
  private String id;

  /** Channel identifier (e.g. "atom", "web", "mobile"). */
  private String channel;

  /** Journey identifier (e.g. "banca-group-renewal", "retail-fresh"). */
  private String journey;

  /** Journey flow variant (e.g. "DEFAULT", "SIMPLIFIED"). */
  @Builder.Default
  private String journeyFlow = "DEFAULT";

  /** Flow variant within the journey flow (e.g. "DEFAULT", "PREMIUM"). */
  @Builder.Default
  private String flowVariant = "DEFAULT";

  /** User persona/role (e.g. "customer", "agent", "admin"). */
  @Builder.Default
  private String persona = "customer";

  /** Checkout type (e.g. "STANDARD", "EXPRESS", "QUICK"). */
  @Builder.Default
  private String checkout = "STANDARD";

  /** Current step in the checkout flow (e.g. "CHECKOUT", "REVIEW", "PAYMENT"). */
  @Builder.Default
  private String step = "CHECKOUT";

  /** Redirection configuration for various navigation scenarios. */
  @Builder.Default
  private RedirectionConfig redirectionConfig = new RedirectionConfig();

  /** Configuration for editable/non-editable elements in the UI. */
  @Builder.Default
  private Map<String, EditableElementConfig> editableConfig = new HashMap<>();

  /** Downstream service configuration for routing. */
  @Builder.Default
  private ServiceConfig serviceConfig = new ServiceConfig();

  /** Whether this configuration is active. */
  @Builder.Default
  private boolean active = true;

  /** Configuration version. */
  @Builder.Default
  private String version = "1.0.0";

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class RedirectionConfig {
    @Builder.Default
    private NavigationConfig homePage = new NavigationConfig();

    @Builder.Default
    private NavigationConfig backButton = new NavigationConfig();
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class NavigationConfig {
    private String url;
    @Builder.Default
    private Map<String, Object> params = new HashMap<>();
    @Builder.Default
    private boolean enabled = true;
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class EditableElementConfig {
    @Builder.Default
    private boolean isEditable = false;

    @Builder.Default
    private boolean isDisabled = false;

    @Builder.Default
    private boolean isRedirection = false;

    @Builder.Default
    private Map<String, Object> redirectionAttributes = new HashMap<>();
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class ServiceConfig {
    /** Base URL of the downstream service (e.g., group-renewal-svc). */
    private String baseUrl;

    /** Specific endpoint path for checkout operations. */
    @Builder.Default
    private String checkoutEndpoint = "/checkout";

    /** HTTP timeout in milliseconds. */
    @Builder.Default
    private Integer timeoutMs = 30000;

    /** Whether to enable routing to downstream service. */
    @Builder.Default
    private boolean enabled = true;

    /** Additional headers to send to downstream service. */
    @Builder.Default
    private Map<String, String> headers = new HashMap<>();
  }
}
