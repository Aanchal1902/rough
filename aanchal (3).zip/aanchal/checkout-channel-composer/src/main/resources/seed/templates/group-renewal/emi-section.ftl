<#assign paymentPreferences = groupPaymentPreferences>
{
  "title": "Payment Preference",
  "subTitle": "",
  <#if orderDetails.entity == "customer">
    "isCustomer": true,
    "list": [
      {
        "label": "Payment Type",
        "value": "${paymentPreferences.defaultPaymentTypeLabel}"
      },
      {
        "label": "Payment Method",
        "value": "${paymentPreferences.defaultPaymentMethodLabel}"
      }
    ]
  <#else>
    "form": [
      {
        "id": "paymentMethod",
        "name": "paymentMethod",
        "tag": "card",
        "type": "radio",
        "label": "Payment Method",
        "defaultValue": "${paymentPreferences.defaultPaymentMethodValue}",
        "direction": "row",
        "options": [
          {
            "value": "${paymentPreferences.defaultPaymentMethodValue!"-"}",
            "label": "${paymentPreferences.defaultPaymentMethodLabel!"-"}"
          }
        ],
        "multiSelect": false,
        "isRequired": false,
        <#assign notEditable = !editableContext.editablePaymentMethod>
        "isDisabled": ${notEditable?c},
        "isVisible": true
      },
      {
        "id": "paymentType",
        "name": "paymentType",
        "tag": "card",
        "type": "radio",
        "label": "Payment Type",
        "defaultValue": "${paymentPreferences.defaultPaymentTypeValue}",
        "direction": "row",
        "options": [
          {
            "value": "${paymentPreferences.defaultPaymentTypeValue!"-"}",
            "label": "${paymentPreferences.defaultPaymentTypeLabel!"-"}"
          }
        ],
        "multiSelect": false,
        "isRequired": false,
        <#assign notEditable = !editableContext.editablePaymentMethod>
        "isDisabled": ${notEditable?c},
        "isVisible": true
      }
    ]
  </#if>
}
