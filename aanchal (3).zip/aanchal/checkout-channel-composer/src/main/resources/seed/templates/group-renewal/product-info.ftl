{
  "title": "${productInfo.productName!"-"}",
  "image": "${productInfo.imageUrl!"-"}"
}
