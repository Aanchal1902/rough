<#-- Renders empty when neither condition holds; the composition engine then skips this widget. -->
<#if editableContext.editableAutoRenewal || (autoRenewalEnabled?? && autoRenewalEnabled)>
{
  <#if editableContext.editableAutoRenewal>
    "startIcon": "checkbox",
    "title": "Auto Renewal",
    "name": "autoRenewalEnabled",
    "id": "autoRenewalEnabled",
    "subTitle": "Auto debit mandate will be placed against your bank account for debiting renewal premium, please maintain sufficient balance in your bank account on the renewal due date to enjoy seamless health cover and continuity benefits"
  <#elseif autoRenewalEnabled>
    "title": "Policy Auto Renewal",
    "isCustomer": true,
    "variant": "warning",
    "status": "Active",
    "tooltip": "Auto debit mandate will be placed against your bank account for debiting renewal premium, please maintain sufficient balance in your bank account on the renewal due date to enjoy seamless health cover and continuity benefits",
    "type": "typography",
    "actionsButtons": {
      "onClick": {
        "type": "icon",
        "icon": "info",
        "trigger": "openDialog"
      }
    }
  </#if>
}
</#if>
