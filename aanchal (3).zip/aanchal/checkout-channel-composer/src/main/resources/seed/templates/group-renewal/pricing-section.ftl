<#-- Mirrors the monolith: `pricingSection` alias + include of the shared premium breakup fragment. -->
<#assign pricingSection = groupPricingSection>
<#include "/common/group-premium-breakup.ftl">
