<#-- Customer-only widget. Renders empty for non-customer entities, so the engine skips it. -->
<#if orderDetails.entity == "customer">
{
  "id": "termAndCondition",
  "name": "termAndCondition",
  "title": "Terms & Conditions",
  "label": "I hereby declare that all information provided above is true, and I accept all",
  "actionsButtons": {
    "viewMore": {
      "id": "termsCondition",
      "name": "termsCondition",
      "type": "button",
      "label": "Terms and Conditions",
      "isRequired": false,
      "regexPattern": "",
      "regexErrorMessage": "",
      "endIcon": "arrowRight2",
      "isDisabled": false,
      "isVisible": true,
      "helperText": ""
    }
  },
  "dialogData": {
    "header": {
      "title": "Terms & Conditions",
      "subTitle": "Please read the following terms carefully before proceeding."
    },
    "content": [
      {
        "type": "heading",
        "text": "Declaration – Proposal form"
      },
      {
        "type": "paragraph",
        "text": "The primary duty of the proposer is to fill out the proposal form and also to make sure that the proposal contains all the details correctly. If you or any of the insured person(s) have suffered or suffering from any of the diseases which has not been mentioned in the proposal, the claim that may arise will result in a repudiation of the claim/cancellation of the policy."
      },
      {
        "type": "paragraph",
        "text": "I/we agree that the PAN details and other information provided by me/us in the proposal form may be used by the Company to download/ verify / modify / add my/our KYC documents from the CERSAI* CKYC portal for processing this application. I/We understand that only the acceptable officially valid documents would be relied upon for processing this application. (*Central Registry of Securitization and Asset Reconstruction and security Interest of India) I hereby consent to receiving information from Central KYC Registry through SMS / email on the above registered number/email address."
      },
      {
        "type": "list",
        "items": [
          "I hereby declare, on my behalf and on behalf of all persons proposed to be insured, that the above statements, answers and/or particulars given by me are true and complete in all respects to the best of my knowledge and that I am authorized to propose on behalf of these other persons. ",
          "I understand that the information provided by me will form the basis of the insurance policy, is subject to the Board approved underwriting policy of the insurer and that the policy will come into force only after full payment of the premium chargeable.",
          "I further declare that I will notify in writing any change occurring in the occupation or general health of the life to be insured/proposer after the proposal has been submitted but before communication of the risk acceptance by the company.",
          "I declare that I consent to the company seeking medical information from any doctor or from a hospital who/which at anytime has attended on the person to be insured/proposer or from any past or present employer concerning anything which affects the physical or mental health of the person to be insured/proposer and seeking information from any insurer to whom an application for insurance on the person to be insured/proposer has been made for the purpose of underwriting the proposal and/or claim settlement. ",
          "I authorize the company to share and or seek information pertaining to my proposal including the medical records of the insured/proposer for the sole purpose of underwriting the proposal and /or claims settlement with any Governmental and/or Regulatory authority, Health care provider, which includes sharing of my medical data through ABHA.",
          "I/We understand that my/our information including personally identifiable information may be shared on confidential basis with Company’s service providers and/or authorized government agencies including without limitation CERSAI for servicing of the policy or as required by law. I/We hereby expressly consent and agree to the Company sharing such information with its service providers for collecting or validating my/our KYC documents and information.",
          "In case of any concealment, mis declaration or non-disclosure of any facts, the policy issued based on this proposal form will be treated void ab-initio. Additionally, Star Health shall not be liable for any claim under such policy.",
          "I confirm that the payment is made through my card / bank account. I also confirm that the source of funds for premium paid under this policy is legal.",
          "I hereby confirm that the features of the product have been understood by me.",
          "I hereby authorize Star Health and Allied Insurance Company to contact me through any mode of communication for any and all service-related purposes (which shall include but is not limited to servicing of policy, claim settlement, renewal reminders, renewal updates etc). It will override my registry on the NCPR (National Customer Preference Register).",
          "I would like to contribute in creating a healthier, greener and cleaner environment by receiving my Insurance Policy documents and service-related communications only via electronic mode.",
          "I/We declare and confirm that I/we have read and understood the Company’s Privacy Policy published on its website and consent to it.",
          "I/We acknowledge the Company’s assurance to ensure courteous and professional conduct by the Company’s staff and representatives in all their interactions with me, whether in person, through email, telephone or any other online or offline platforms. In response, I/We irrevocably agree to reciprocate this standard of professionalism and respect in all communications with the Company. Any unprofessional or inappropriate behaviour may result in legal action under the Bharatiya Nyaya Sanhita, Act 2023.",
          "Prohibition of Rebates: Section 41 of Insurance Act 1938. 1. No person shall allow or offer to allow, either directly or indirectly, as an inducement to any person to take out or renew or continue an insurance in respect of any kind of risk relating to lives or property in India, any rebate of the whole or part of the commission payable or any rebate of the premium shown on the policy, nor shall any person taking out or renewing or continuing a policy accept any rebate, except such rebate as may be allowed in accordance with the published prospectuses or tables of the insurer. 2. Any person making default in complying with the provisions of this section shall be liable for a penalty which may extend to ten lakh rupees."
        ]
      }
    ]
  }
}
</#if>
