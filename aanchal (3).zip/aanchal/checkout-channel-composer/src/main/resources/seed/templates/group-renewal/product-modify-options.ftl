{
  "form": [
    <#if masterPolicies?? && (masterPolicies?size > 0)>
    <#list masterPolicies as currMasterPolicy>
      {
        "id": "modifyOptions",
        "type": "modifyOptionsCard",
        "title": "${currMasterPolicy.masterPolicyName!"-"}",
        "subTitle": "",
        "fields": [
          <#if currMasterPolicy.plans?? && (currMasterPolicy.plans?size > 0)>
          <#list currMasterPolicy.plans as plan>
            <#if plan.isStatic>
              {
                "id": "${plan.updatedKey}",
                "name": "${plan.updatedKey}",
                "tag": "${plan.updatedKey}",
                "type": "select",
                "variant": "primary",
                "label": "${plan.planName!"-"}",
                "defaultValue": "${plan.selectedValue!"-"}",
                "gridSize": {
                  "xs": 6,
                  "md": 6
                },
                "options": [
                  <#if plan.sumInsureds?? && (plan.sumInsureds?size > 0)>
                  <#list plan.sumInsureds as sumInsured>
                    {
                      "value": "${sumInsured.value!"-"}",
                      "label": "${sumInsured.label!"-"}"
                    }<#if sumInsured_has_next>,</#if>
                  </#list>
                  </#if>
                ],
                "multiSelect": false,
                "isRequired": false,
                <#assign notEditable = !editableContext.editableSumInsured>
                "isDisabled": ${notEditable?c},
                "isVisible": true
              }
            <#else>
              {
                "id": "${plan.updatedKey}",
                "name": "${plan.updatedKey}",
                "tag": "${plan.updatedKey}",
                "type": "number",
                "variant": "primary",
                "placeHolder": "Select any value from ${plan.minLabel!'0'} to ${plan.maxLabel!'0'} (inclusive).",
                "label": "${plan.planName!"-"}",
                "defaultValue": "${plan.selectedValue!"-"}",
                "conditionalRender": {},
                "min": "${plan.minValue!"0"}",
                "max": "${plan.maxValue!"0"}",
                "isRequired": false,
                <#assign notEditable = !editableContext.editableSumInsured>
                "isDisabled": ${notEditable?c},
                "isVisible": true,
                "gridSize": {
                  "xs": 6,
                  "md": 6
                }
              }
            </#if>
            <#if plan_has_next>,</#if>
          </#list>
          </#if>

          <#assign periodSection = currMasterPolicy.periodSection>
          <#if periodSection.isStatic>
            ,{
              "id": "${periodSection.updatedKey}",
              "name": "${periodSection.updatedKey}",
              "tag": "${periodSection.updatedKey}",
              "type": "select",
              "variant": "primary",
              "label": "Policy Period",
              "defaultValue": "${periodSection.selectedValue!""}",
              "gridSize": {
                "xs": 12
              },
              "options": [
                <#if periodSection.periods?? && (periodSection.periods?size > 0)>
                <#list periodSection.periods as period>
                  {
                    "value": "${period.value!""}",
                    "label": "${period.label!""}"
                  }<#if period_has_next>,</#if>
                </#list>
                </#if>
              ],
              "multiSelect": false,
              "isRequired": false,
              <#assign notEditable = !editableContext.editablePolicyPeriod>
              "isDisabled": ${notEditable?c},
              "isVisible": true
            }
          <#else>
            ,{
              "id": "${periodSection.updatedKey}",
              "name": "${periodSection.updatedKey}",
              "tag": "${periodSection.updatedKey}",
              "gridSize": {
                "xs": 12
              },
              "type": "number",
              "variant": "primary",
              "label": "Policy Period",
              "defaultValue": "${periodSection.selectedValue}",
              "placeHolder": "Select any value from ${periodSection.minLabel!'0'} to ${periodSection.maxLabel!'0'} (inclusive).",
              "conditionalRender": {},
              "min": "${periodSection.minValue!"0"}",
              "max": "${periodSection.maxValue!"0"}",
              "isRequired": false,
              <#assign notEditable = !editableContext.editablePolicyPeriod>
              "isDisabled": ${notEditable?c},
              "isVisible": true
            }
          </#if>
        ]
      }<#if currMasterPolicy_has_next>,</#if>
    </#list>
    </#if>
  ]
}
