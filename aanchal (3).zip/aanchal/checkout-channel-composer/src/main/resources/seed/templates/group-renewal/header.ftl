{
  "title": "Checkout",
  "seoTitle": "Checkout",
  "actionButtons": {
    "goBack": {
      "id": "goBackButton",
      "name": "goBackButton",
      "type": "button",
      "label": "Go Back",
      "isRequired": true,
      "className": "fieldClass",
      "startIcon": "back",
      "endIcon": "",
      "extraProps": {},
      "containerConfig": {},
      "placeholder": "",
      "isDisabled": false,
      "isVisible": true,
      "validations": {},
      "conditionalRender": {},
      "helperText": ""
    },
    <#if orderDetails.entity == "customer">
      "supportButton": {
        "id": "supportButton",
        "name": "supportButton",
        "type": "button",
        "label": "",
        "isRequired": true,
        "className": "fieldClass",
        "startIcon": "support",
        "endIcon": "",
        "extraProps": {},
        "containerConfig": {},
        "placeholder": "",
        "isDisabled": false,
        "isVisible": true,
        "validations": {},
        "conditionalRender": {},
        "helperText": "",
        "actionsButtons": {
          "onClick": {}
        },
        "dialogData": {
          "header": {
            "title": "Your Advisor",
            "subTitle": "If you need any assistance, please reach out to your advisor"
          },
          "advisorInfo": {
            "fullName": "${advisorDetails.advisorFullName!""}",
            "code": "${advisorDetails.advisorCode!""}",
            "mobileNumber": "${advisorDetails.advisorMobileNumber!""}"
          }
        }
      }
    <#else>
      "actionMenu": {
        "id": "actionMenu",
        "name": "actionMenu",
        "type": "button",
        "label": "",
        "isRequired": true,
        "className": "fieldClass",
        "startIcon": "moreH",
        "endIcon": "",
        "extraProps": {},
        "containerConfig": {},
        "placeholder": "",
        "isDisabled": false,
        "isVisible": true,
        "validations": {},
        "conditionalRender": {},
        "helperText": "",
        "menus": [
          {
            "id": "exit",
            "label": "Exit",
            "startIcon": "exit",
            "action": {
              "onClick": {
                "type": "href",
                "url": "${channelConfig.redirectionUrls.goToBackHomePageUrl!""}",
                "target": ""
              }
            }
          }
        ]
      }
    </#if>
  }
}
