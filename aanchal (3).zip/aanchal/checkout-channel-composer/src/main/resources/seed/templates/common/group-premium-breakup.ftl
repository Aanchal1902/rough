<#--
  PLACEHOLDER for the shared premium-breakup fragment.

  The original `common/group-premium-breakup.ftl` was not included in the source that was
  handed over, so this is a best-effort reconstruction driven by the `pricingSection` alias
  (set to `groupPricingSection` by the caller). Replace the body below with the real fragment
  when migrating — the important part is that it lives here as a DB template named
  "common/group-premium-breakup.ftl" and is resolved via <#include> exactly like the monolith.
-->
{
  "title": "${(pricingSection.title)!"Premium Breakup"}",
  "totalPremium": "${(pricingSection.totalPremium)!"0"}",
  "netPremium": "${(pricingSection.netPremium)!"0"}",
  "totalGst": "${(pricingSection.totalGst)!"0"}",
  "breakup": [
    <#if (pricingSection.lineItems)?? && (pricingSection.lineItems?size > 0)>
    <#list pricingSection.lineItems as item>
      {
        "label": "${(item.label)!"-"}",
        "value": "${(item.value)!"0"}"
      }<#if item_has_next>,</#if>
    </#list>
    </#if>
  ]
}
