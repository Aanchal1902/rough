package com.star.checkout.composer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.star.checkout.composer.dto.ComposeRequest;
import com.star.checkout.composer.dto.ComposedResponse;
import com.star.checkout.composer.exception.ChannelComposerException;
import com.star.checkout.composer.model.ChannelConfig;
import com.star.checkout.composer.model.Widgets;
import com.star.checkout.composer.repository.ChannelConfigRepository;
import com.star.checkout.composer.repository.ChannelWidgetConfigRepository;
import com.star.checkout.composer.repository.WidgetsRepository;
import com.star.checkout.composer.service.impl.ChannelComposerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ChannelComposerServiceImplTest {

  @Mock
  private ChannelConfigRepository channelConfigRepository;
  @Mock
  private ChannelWidgetConfigRepository channelWidgetConfigRepository;
  @Mock
  private WidgetsRepository widgetsRepository;

  private ChannelComposerServiceImpl service;

  @BeforeEach
  void setUp() {
    service = new ChannelComposerServiceImpl(
        channelConfigRepository, channelWidgetConfigRepository, widgetsRepository, new ObjectMapper());
  }

  @Test
  void composesEnabledWidgetsInOrder() {
    stubChannel();
    stubWidgets(
        widget("planDetails", "PLAN_DETAILS_WIDGET", 1, true, "{\"title\":\"Plan Details\"}"),
        widget("proposerDetails", "PROPOSER_DETAILS_WIDGET", 2, true, "{\"name\":\"John Doe\"}"));

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).containsExactly("planDetails", "proposerDetails");
    assertThat(response.getFailedWidgets()).isEmpty();
    assertThat(response.getData().get("planDetails").get("title").asText()).isEqualTo("Plan Details");
    assertThat(response.getData().get("proposerDetails").get("name").asText()).isEqualTo("John Doe");
  }

  @Test
  void skipsWidgetsWithNoTemplate() {
    stubChannel();
    stubWidgets(
        widget("planDetails", "PLAN_DETAILS_WIDGET", 1, true, "{\"title\":\"Plan Details\"}"),
        widget("emptyWidget", "EMPTY_WIDGET", 2, true, null));

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).containsExactly("planDetails");
    assertThat(response.getFailedWidgets()).containsExactly("emptyWidget");
    assertThat(response.getData().has("planDetails")).isTrue();
    assertThat(response.getData().has("emptyWidget")).isFalse();
  }

  @Test
  void skipsDisabledWidgets() {
    stubChannel();
    stubWidgets(
        widget("planDetails", "PLAN_DETAILS_WIDGET", 1, true, "{\"title\":\"Plan Details\"}"),
        widget("disabledWidget", "DISABLED_WIDGET", 2, false, "{\"title\":\"Disabled\"}"));

    ComposedResponse response = compose();

    assertThat(response.getRenderedWidgets()).containsExactly("planDetails");
    assertThat(response.getFailedWidgets()).isEmpty();
  }

  @Test
  void handlesTemplateVariableReplacement() {
    stubChannelWithData();
    stubWidgets(
        widget("planDetails", "PLAN_DETAILS_WIDGET", 1, true,
               "{\"title\":\"${planDetails.title!\\\"Default\\\"}\", \"type\":\"${planDetails.type!\\\"Unknown\\\"}\"}"));

    Map<String, Object> data = Map.of(
        "planDetails", Map.of("title", "My Plan", "type", "Health Insurance")
    );

    ComposedResponse response = service.compose(ComposeRequest.builder()
        .channel("atom")
        .journey("banca-group-renewal")
        .data(data)
        .build());

    assertThat(response.getRenderedWidgets()).containsExactly("planDetails");
    assertThat(response.getData().get("planDetails").get("title").asText()).isEqualTo("My Plan");
    assertThat(response.getData().get("planDetails").get("type").asText()).isEqualTo("Health Insurance");
  }

  @Test
  void throwsWhenChannelConfigMissing() {
    when(channelConfigRepository.findByChannelAndJourneyAndJourneyFlowAndFlowVariantAndPersonaAndCheckoutAndStepAndActiveTrue(
        "nonexistent", "journey", "DEFAULT", "DEFAULT", "customer", "STANDARD", "CHECKOUT"))
        .thenReturn(Optional.empty());
    when(channelConfigRepository.findByChannelAndJourneyAndActiveTrue("nonexistent", "journey"))
        .thenReturn(Optional.empty());

    assertThatThrownBy(() -> service.compose(ComposeRequest.builder()
        .channel("nonexistent")
        .journey("journey")
        .build()))
        .isInstanceOf(ChannelComposerException.class)
        .hasMessageContaining("No channel configuration found");
  }

  @Test
  void throwsWhenRequiredFieldsMissing() {
    assertThatThrownBy(() -> service.compose(ComposeRequest.builder().build()))
        .isInstanceOf(ChannelComposerException.class)
        .hasMessageContaining("Both channel and journey are required");
  }

  // --- helpers ---

  private ComposedResponse compose() {
    return service.compose(ComposeRequest.builder()
        .channel("atom")
        .journey("banca-group-renewal")
        .data(Map.of())
        .build());
  }

  private void stubChannel() {
    ChannelConfig channelConfig = ChannelConfig.builder()
        .channel("atom")
        .journey("banca-group-renewal")
        .journeyFlow("DEFAULT")
        .flowVariant("DEFAULT")
        .persona("customer")
        .checkout("STANDARD")
        .step("CHECKOUT")
        .active(true)
        .version("1.0.0")
        .build();

    lenient().when(channelConfigRepository.findByChannelAndJourneyAndJourneyFlowAndFlowVariantAndPersonaAndCheckoutAndStepAndActiveTrue(
        "atom", "banca-group-renewal", "DEFAULT", "DEFAULT", "customer", "STANDARD", "CHECKOUT"))
        .thenReturn(Optional.of(channelConfig));
  }

  private void stubChannelWithData() {
    stubChannel();
  }

  private void stubWidgets(Widgets.WidgetDefinition... defs) {
    Widgets widgets = Widgets.builder()
        .channelId("atom")
        .subChannelId("banca-group-renewal")
        .coreSystem("group-renewal")
        .journey("renewal")
        .role("customer")
        .step("checkout")
        .status("ACTIVE")
        .configVersion(1)
        .widgets(List.of(defs))
        .build();

    when(widgetsRepository.findByChannelIdAndSubChannelIdAndStatus("atom", "banca-group-renewal", "ACTIVE"))
        .thenReturn(Optional.of(widgets));
  }

  private Widgets.WidgetDefinition widget(String capability, String widget, int order, boolean enabled, String template) {
    return Widgets.WidgetDefinition.builder()
        .capability(capability)
        .widget(widget)
        .version("1.0.0")
        .enabled(enabled)
        .order(order)
        .template(template)
        .build();
  }
}
