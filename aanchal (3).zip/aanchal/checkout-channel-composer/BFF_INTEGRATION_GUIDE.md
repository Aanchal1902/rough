# BFF Integration Guide - Checkout Routing

This guide explains how to integrate the routing functionality in your BFF `checkoutPage()` method.

## Overview

The checkout-channel-composer service now provides routing information to help BFF decide which downstream service to call, then composes the final response.

## Integration Flow

### 1. Update Your BFF checkoutPage() Method

```java
@RestController
public class CheckoutController {

    @Autowired
    private CheckoutRoutingService checkoutRoutingService;
    
    @Autowired
    private ChannelComposerService channelComposerService;
    
    @Autowired
    private RestTemplate restTemplate; // or WebClient
    
    public ResponseEntity<ApiResponse> checkoutPage(
        @RequestParam(name = PLACEHOLDER_SUB_ORDER_ID_KEY, required = false) String subOrderId,
        @RequestParam(name = PLACEHOLDER_ACTIVE_TAB_KEY, required = false) String activeTab,
        @RequestBody @Valid CheckoutRequest checkoutRequest,
        @RequestParam(name = PLACEHOLDER_MODE_KEY, required = false) String mode,
        HttpServletRequest request) {
        
        log.info("Received Checkout Page API Request");
        CheckoutParamsRequest checkoutParams = commonUtils.getCheckoutParams(checkoutRequest, subOrderId, activeTab, mode);
        
        // **NEW: Check if routing is enabled**
        String channel = getChannelFromRequest(checkoutRequest); // e.g., "atom"
        String journey = getJourneyFromRequest(checkoutRequest); // e.g., "banca-group-renewal"
        
        boolean useRouting = checkoutRoutingService.isRoutingEnabled(channel, journey);
        
        if (useRouting) {
            // **NEW ROUTING FLOW**
            return handleRoutingFlow(checkoutParams, channel, journey, request);
        } else {
            // **LEGACY FLOW - existing code**
            ApiResponse response = coreSystemStrategyExecutor.buildCheckoutPage(checkoutParams, request);
            orderProcessingUtil.addingFlow(MDC.get(SessionUtil.HEADER_ORDER_ID), 
                UserUpdateActions.CHECKOUT_PAGE, checkoutParams.getSessionResponse(), 
                MDC.get(UserUpdateActions.REQUEST_UPDATE_KEY), request);
            return ResponseEntity.ok(response);
        }
    }
    
    private ResponseEntity<ApiResponse> handleRoutingFlow(CheckoutParamsRequest checkoutParams, 
                                                         String channel, String journey, 
                                                         HttpServletRequest request) {
        try {
            // Step 1: Get routing info from composer service
            RoutingInfo routingInfo = checkoutRoutingService.getRoutingInfo(channel, journey, null);
            
            if (!routingInfo.isValid()) {
                log.warn("Invalid routing info for {}/{}, falling back to legacy", channel, journey);
                return handleLegacyFlow(checkoutParams, request);
            }
            
            // Step 2: Call downstream service
            Object rawResponse = callDownstreamService(routingInfo, checkoutParams);
            
            // Step 3: Compose final response using composer
            ComposeRequest composeRequest = ComposeRequest.builder()
                .channel(channel)
                .journey(journey)
                .data(rawResponse)
                .build();
                
            ComposedResponse composedResponse = channelComposerService.compose(composeRequest);
            
            // Step 4: Build final API response
            ApiResponse response = new ApiResponse();
            response.setMessage("Checkout page fetched successfully!");
            response.setData(composedResponse.getData());
            
            // Audit logging (same as before)
            orderProcessingUtil.addingFlow(MDC.get(SessionUtil.HEADER_ORDER_ID), 
                UserUpdateActions.CHECKOUT_PAGE, checkoutParams.getSessionResponse(), 
                MDC.get(UserUpdateActions.REQUEST_UPDATE_KEY), request);
                
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Error in routing flow: {}", e.getMessage(), e);
            // Fallback to legacy flow on error
            return handleLegacyFlow(checkoutParams, request);
        }
    }
    
    private Object callDownstreamService(RoutingInfo routingInfo, CheckoutParamsRequest checkoutParams) {
        // Build request for downstream service (same format as before)
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        // Add any custom headers from routing config
        routingInfo.getHeaders().forEach(headers::add);
        
        HttpEntity<CheckoutParamsRequest> requestEntity = new HttpEntity<>(checkoutParams, headers);
        
        // Set timeout from routing config
        RestTemplate template = createRestTemplateWithTimeout(routingInfo.getTimeoutMs());
        
        // Call downstream service
        ResponseEntity<Object> response = template.postForEntity(
            routingInfo.getFullServiceUrl(), 
            requestEntity, 
            Object.class
        );
        
        return response.getBody();
    }
    
    private ResponseEntity<ApiResponse> handleLegacyFlow(CheckoutParamsRequest checkoutParams, 
                                                        HttpServletRequest request) {
        // Your existing legacy flow
        ApiResponse response = coreSystemStrategyExecutor.buildCheckoutPage(checkoutParams, request);
        orderProcessingUtil.addingFlow(MDC.get(SessionUtil.HEADER_ORDER_ID), 
            UserUpdateActions.CHECKOUT_PAGE, checkoutParams.getSessionResponse(), 
            MDC.get(UserUpdateActions.REQUEST_UPDATE_KEY), request);
        return ResponseEntity.ok(response);
    }
}
```

### 2. Helper Methods You'll Need

```java
private String getChannelFromRequest(CheckoutRequest checkoutRequest) {
    // Extract channel from your request structure
    // This depends on your existing CheckoutRequest structure
    return "atom"; // example
}

private String getJourneyFromRequest(CheckoutRequest checkoutRequest) {
    // Extract journey from your request structure
    return "banca-group-renewal"; // example
}

private RestTemplate createRestTemplateWithTimeout(Integer timeoutMs) {
    RestTemplate template = new RestTemplate();
    
    HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
    factory.setConnectTimeout(timeoutMs);
    factory.setReadTimeout(timeoutMs);
    
    template.setRequestFactory(factory);
    return template;
}
```

## Configuration

### 1. Channel Config in Database

The routing information is stored in your `channel_config` collection:

```json
{
  "channel": "atom",
  "journey": "banca-group-renewal",
  "serviceConfig": {
    "baseUrl": "http://group-renewal-svc:8080",
    "checkoutEndpoint": "/api/v1/checkout",
    "timeoutMs": 30000,
    "enabled": true,
    "headers": {
      "Content-Type": "application/json",
      "Accept": "application/json"
    }
  }
}
```

### 2. Toggle Control

You control routing per channel/journey by setting:
- `serviceConfig.enabled: true` → Use routing
- `serviceConfig.enabled: false` → Use legacy flow

## API Contracts

### 1. RoutingInfo Response

```java
public class RoutingInfo {
    private boolean routingEnabled;
    private String serviceBaseUrl;
    private String checkoutEndpoint;
    private Integer timeoutMs;
    private Map<String, String> headers;
    
    public String getFullServiceUrl(); // baseUrl + endpoint
    public boolean isValid();
}
```

### 2. Composer Service Methods

```java
// Check if routing enabled
boolean enabled = checkoutRoutingService.isRoutingEnabled("atom", "banca-group-renewal");

// Get routing info
RoutingInfo info = checkoutRoutingService.getRoutingInfo("atom", "banca-group-renewal", null);

// Compose response (existing)
ComposedResponse response = channelComposerService.compose(composeRequest);
```

## Error Handling

1. **Invalid routing config** → Fall back to legacy flow
2. **Downstream service error** → Fall back to legacy flow  
3. **Compose method error** → Return error to Star Checkout

## Testing

1. **Legacy flow**: Set `serviceConfig.enabled: false`
2. **Routing flow**: Set `serviceConfig.enabled: true` with valid service URL
3. **Fallback**: Use invalid service URL to test fallback to legacy

## Benefits

- **Gradual rollout**: Enable routing per channel/journey
- **Zero downtime**: Automatic fallback to legacy flow
- **Centralized config**: All routing rules in database
- **Consistent FTL**: Same template processing for all responses